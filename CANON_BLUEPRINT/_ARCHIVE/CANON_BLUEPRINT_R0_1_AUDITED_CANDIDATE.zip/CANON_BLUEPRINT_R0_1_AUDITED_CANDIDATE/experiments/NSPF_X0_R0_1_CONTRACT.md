# NSPF-X0 R0.1 — FALSIFICATION CAMPAIGN CONTRACT

Status: `DESIGN CANDIDATE / PREREGISTRATION TEMPLATE`

This campaign does not redefine FE256. FE256 remains static semantic acceptance;
NSPF-X0 tests the stronger information-neuronalization/developmental hypothesis.

Required interventions:

1. ID permutation
2. alias replacement / multilingual parity
3. masked semantic slot with support retained
4. Pack-A/Pack-B causal support ablation
5. physical clock/spacing invariance with fixed logical events
6. event-jitter/stall robustness
7. reset/restore learned state
8. sensor grounding before alias
9. false-teacher + anti-parrot
10. cache on/off semantic equivalence
11. unseen-instance capability/skill transfer
12. 4→8→16 structural transfer with primitive shortcut disabled
13. runtime knowledge-pack dependence
14. stale-cache / generation switch
15. capability-binding / no-binding-no-action / safety veto

Every test must preregister:

```text
hypothesis
DUT/artifact hashes
input/initial state
control
intervention
expected semantic result
expected status/proof changes
failure criterion
allowed claim
raw evidence to save
```

A pass supports only the bounded tested property. It does not imply AGI,
universal reasoning, human-level grounding or novelty.
