Sau tất cả các bản thiết kế, Deep Research, correction về DDR, memory stratification và các boundary của `NATIVE_INFORMATION_NEURONALIZATION_BLUEPRINT_R0`, tôi sẽ **không khóa GOAL theo đoạn mô tả anh vừa đưa nguyên văn**. Lõi tư tưởng đúng, nhưng trong đó còn vài câu quá mức bằng chứng: “Truth Engine”, “100% chính xác”, “giao hàng nghìn nhánh trong 1 clock”, “UNKNOWN thì lập tức hỏi Teacher”, hay xem BRAM chính là muscle memory.

Tôi đã kiểm tra catalog của `@AMD`: hiện các skill AMD được cung cấp tập trung vào Instinct/vLLM, TraceLens và local AI, **không có skill chuyên Artix-7/Vivado/FPGA architecture phù hợp cho tác vụ này**. Vì vậy tôi không giả danh đây là kết luận từ một AMD-FPGA plugin; các thông số phần cứng dưới đây được kiểm lại từ tài liệu AMD/Digilent chính thức.

Digilent xác nhận Arty A7-100T dùng XC7A100T, có 256 MB DDR3L, bus 16-bit ở 333 MHz, tương đương **667 MT/s**; vì mỗi transfer là 2 byte nên peak lý thuyết là **1.334 GB/s decimal ≈ 1.24 GiB/s**. Con số 133 MB/s trước đó sai hệ số 10. FPGA có 4,860 Kb block RAM, tức 135 BRAM36, xấp xỉ 607.5 KiB theo cách quy đổi nhị phân.

Và đây là phiên bản GOAL tôi cho rằng đủ chính xác để **khóa ở đầu project**.

# FINAL CANONICAL GOAL — NATIVE AI

> **[LOCK] Mục tiêu của Native AI là xây dựng một cognitive substrate chạy native trên FPGA/SoC, trong đó tri thức, quan hệ, trạng thái, hành động và kinh nghiệm được biểu diễn thành các đối tượng semantic có kiểu, có định danh và có provenance rõ ràng; chỉ một working set nhỏ được kích hoạt tại một thời điểm và được xử lý bằng event-driven sparse execution.**
>
> **Hệ thống phải tách tuyệt đối tri thức đã xác minh khỏi candidate, episode, failure, skill và learned weight; tách meaning khỏi human-language representation; tách semantic time khỏi physical clock; và tách utility/ranking khỏi truth/proof.**
>
> **Native AI phải có khả năng nhận tri thức đã nạp, truy hồi và suy luận bounded trên tri thức đó; quan sát thế giới qua sensor; thực hiện action thật; học candidate relation, preference và procedure từ experience, demonstration và reward; tạo reusable skill; nhận biết thiếu bằng chứng; yêu cầu thêm thông tin khi policy cho phép; và giữ lại failure/experience để cải thiện hành vi.**
>
> *Mọi answer, action hoặc knowledge promotion cuối cùng đều phải đi qua ASTRA để kiểm legality, evidence, provenance, conflict, completeness và epistemic status. Q, SPEAR, GEMINI, Teacher, cache hotness hoặc learned score không được thay thế authority này.*\*
>
> **Human language và dense neural models là các adapter/perception sidecar tùy chọn. Chúng có thể giúp biến text/image/audio thành native records hoặc render native result trở lại ngôn ngữ con người, nhưng không được trở thành hidden truth engine của hệ thống.**
>
> **Giả thuyết nghiên cứu trung tâm là: cognition hữu ích có thể được xây dựng bằng cách “neuronalize information” — biến explicit semantic objects và typed relations thành các đơn vị persistent có thể kích hoạt thưa, thay vì buộc phần lớn tri thức phải tồn tại ẩn trong dense learned weights. Giả thuyết này phải được chứng minh hoặc bác bỏ bằng transfer, grounding, causal ablation, reset/restore, permutation và silicon evidence.**

Đây mới là GOAL tổng thể phù hợp với Master Blueprint hiện tại: persistent semantic plane + temporal event plane + Working Mind + Q\*/SPEAR/Skill/FEM + ASTRA, chứ không phải chỉ một knowledge graph truy vấn tĩnh.

---

# 1. Native AI thực sự đang cố tạo ra cái gì?

Tên kỹ thuật phù hợp nhất hiện tại là:

## **FPGA-Native Evidence-Governed Cognitive Substrate**

hoặc nếu giữ tên kiến trúc:

## **Native Semantic Pulse Fabric**

Nó **không phải một LLM mini**.

Nhưng cũng không nên nói nó “đoạn tuyệt hoàn toàn với neural AI”.

Mô hình dài hạn hợp lý hơn là:

```text
PERCEPTION / HUMAN LANGUAGE
    neural / DSP / symbolic / sensor adapters
                    │
                    ▼
        NATIVE INFORMATION BOUNDARY
                    │
        ┌───────────┴───────────┐
        ▼                       ▼
 BINARY SEMANTIC          TEMPORAL EVENT
     PLANE                    PLANE
        │                       │
        └───────────┬───────────┘
                    ▼
              WORKING MIND
                    │
          NCG / Q* / SPEAR
             Skill / FEM
                    │
                    ▼
                  ASTRA
                    │
           StructuredResult
```

Dense neural computation có thể tồn tại ở perception/language boundary nếu sau này nó chứng minh được giá trị.

Nhưng:

```text
neural output != truth
```

---

# 2. “Neuronalizing information” chính xác nghĩa là gì?

Đây là phần cần giữ mạnh nhất.

Không phải:

> biến mỗi fact thành một neuron vật lý.

Mà là:

```text
Semantic Unit
≈ virtual neuron-like persistent object

Typed Relation
≈ explicit synapse-like connectivity

Active Frontier
≈ current sparse activation

Semantic Event
≈ pulse/event

Working Memory
≈ temporary activated/bound state
```

Ví dụ:

```text
NODE_102
kind = DEVICE_CLASS

EDGE_812
src = NODE_102
relation = USES_REFRIGERANT
dst = NODE_307
```

Khi không được dùng:

```text
stored but inactive
```

Khi query kích hoạt:

```text
NODE_102
   ↓
USES_REFRIGERANT
   ↓
NODE_307
```

Chỉ phần graph liên quan được đưa vào working state.

Đây là ý nghĩa đúng nhất của:

> **Persistent information + sparse activation**

Không phải toàn knowledge base đồng thời “phát xung”.

---

# 3. 3 tầng memory: giữ ý tưởng, nhưng khóa lại định nghĩa

Đây là distinction bắt buộc:

## Logical Cognitive Class × Physical Memory Tier

Không được viết:

```text
FACT = DDR
SKILL = BRAM
INSTINCT = LUT
```

Mà phải là:

```text
               PHYSICAL PLACEMENT
             T0        T1        T2
           Logic      BRAM      DDR/HBM

FACT                   cache     canonical
SKILL                  hot       canonical
EPISODE                           canonical
FAILURE                hot       canonical
POLICY WEIGHT          active    checkpoint
PROOF                  scratch   archive
```

Tức:

> **một FACT vẫn là FACT dù nó đang ở DDR hay được cache vào BRAM.**

Đây đã phù hợp với R2 blueprint: placement không được thay đổi epistemic class.

---

# 4. Tier-0 — thứ anh gọi là “Bản năng”

Có thể giữ chữ **Instinct** như metaphor.

Nhưng tên kỹ thuật:

## T0 — Immutable Semantic Control Plane

T0 chứa:

```text
exact comparator
hash primitive
AND / OR / NOT
type checks
CRC/protocol logic
routing
schema/ABI laws
ASTRA state/status rules
safety/legality veto
bounded graph machinery
primitive arithmetic
```

T0 **không mặc định chứa**:

```text
RAC_WALL -> R32
LED3 = SUCCESS
teacher statement
learned fact
Q* preference
episode
```

Và một correction quan trọng:

> LUT không có phép màu “so hàng nghìn nhánh trong một clock”.

Có thể tạo nhiều comparator song song, nhưng parallelism phải trả bằng:

```text
LUT
routing
fanout
timing
power
```

XC7A100T có 63,400 LUT, nhưng không có nghĩa toàn bộ dành cho intersection engine.

Do đó hardware intersection thực tế có thể dùng:

```text
hash/tag lookup
sorted-posting merge
small bitset
bounded comparator lanes
CAM for small exact set
```

tùy workload.

---

# 5. Tier-1 — điều anh đang gọi “Trí nhớ cơ bắp”

Ý tưởng của anh ở đây **rất có giá trị**, nhưng tôi sẽ sửa định nghĩa.

T1 không phải bản thân “muscle memory”.

## T1 — Hot Cognitive Working Store

BRAM giữ:

```text
current QueryRecord
active context
role bindings
active goal
frontier
visited set/filter
Top-K candidate queue
hot directory entries
hot posting pages
hot edge/value records
proof scratch
hot skills
Q*/SPEAR working state
recent FEM prototypes
FIFO / event buffers
```

Nghĩa là T1 thực hiện hai chức năng:

```text
WORKING MEMORY
+
HOT CACHE
```

và có thể giữ:

```text
hot PROCEDURAL MEMORY
```

nhưng ba lớp đó vẫn khác nhau về logic.

Nếu muốn tiếp tục dùng từ “muscle memory”, hãy dành nó cho:

> **SKILL/procedural memory đã được học, verify và có khả năng tái sử dụng.**

Không dành chữ đó cho toàn BRAM.

---

# 6. Tier-2 — Long-term canonical memory

## T2 — Canonical Cognitive Memory Store

Trên Arty hiện tại là DDR3L.

Chứa:

```text
Node
Edge
Value
Context
Provenance

forward postings
reverse postings

candidate facts
episodes
failures
skills
policy checkpoints
long-term learning state
conflict records
proof artifacts
```

DDR không phải “toàn bộ causal graph”.

Graph phải bao gồm nhiều relation:

```text
IS_A
PART_OF
USES
HAS_STATE
NAMED_AS
BEFORE
AFTER
CORRELATES_WITH
CAUSES
ACHIEVES
FAILED_AT
...
```

và:

```text
CORRELATES_WITH != CAUSES
```

luôn phải giữ.

---

# 7. Ý tưởng “BRAM anchor → chỉ mở nhánh DDR cần thiết” là đúng

Nhưng tên kỹ thuật chính xác nên là:

## **Bounded Relevance-Guided Graph Traversal**

chứ không nhất thiết gọi mọi thứ là spreading activation.

Flow:

```text
Query / Goal
     │
     ▼
T1 active anchors
     │
     ▼
exact directory lookup
     │
     ▼
selected posting page(s)
     │
     ▼
DDR fetch
     │
     ▼
relation/context filter
     │
     ▼
new frontier
```

Nó không:

```text
scan toàn bộ DDR
```

mà đi:

```text
ID
→ directory
→ posting pointer
→ selected adjacency
```

Đây là điểm cực quan trọng.

BRAM không cần chứa cả graph.

Nó giữ:

```text
working set
```

của graph.

---

# 8. Intersection reasoning của anh cũng nên giữ — nhưng là một operator

Ví dụ query muốn tìm bridge giữa A và B:

```text
Frontier_A = neighbors(A)
Frontier_B = neighbors(B)
```

sau đó:

```text
Intersection =
Frontier_A ∩ Frontier_B
```

Z có thể là candidate rất mạnh.

Hoặc dùng bidirectional search:

```text
A → ... → Z
B ← ... ← Z
```

Điều này có thể giảm branching rất đáng kể.

Nhưng:

> intersection không phải reasoning universal.

Một số query chỉ cần:

```text
DIRECT
```

một số:

```text
REVERSE
```

một số:

```text
VALUE/RANGE
```

một số:

```text
CONTEXT FILTER
```

một số:

```text
MULTIHOP
```

một số:

```text
PROVENANCE
```

một số:

```text
TEMPORAL
```

và causal reasoning cần:

```text
intervention
+
ablation
```

chứ không phải chỉ intersection.

---

# 9. Top-K cũng không phải đáp án

Một distinction phải khóa:

```text
Candidate Top-K != ANSWER
```

Flow đúng:

```text
candidate generation
       ↓
SPEAR / relevance ranking
       ↓
Top-K
       ↓
ASTRA verification
       ↓
proof + provenance + context
       ↓
ANSWER / UNKNOWN / CONFLICT / ...
```

Nếu Top-K bỏ mất candidate cần thiết do budget:

```text
SEARCH_INCOMPLETE
```

không được:

```text
UNKNOWN
```

---

# 10. Trạng thái nhận thức mới chính là “anti-hallucination” thật

Tôi không gọi nó:

> cỗ máy không bao giờ nói dối.

Không hệ thống thực tế nào được bảo đảm như vậy.

Tên kỹ thuật đúng hơn:

## **Fail-Closed Epistemic Reasoning**

ASTRA trả:

```text
ANSWER
UNKNOWN
CONFLICT
SEARCH_INCOMPLETE
UNSUPPORTED_QUERY
DATA_INTEGRITY_FAIL
```

Adapter có thêm:

```text
PARSE_ERROR
```

Khác nhau hoàn toàn.

Ví dụ:

### Không có support

```text
UNKNOWN
```

### Có support mâu thuẫn

```text
CONFLICT
```

### Chưa tìm hết vì budget

```text
SEARCH_INCOMPLETE
```

### Knowledge Pack lỗi

```text
DATA_INTEGRITY_FAIL
```

### Người dùng hỏi thứ hệ chưa hỗ trợ

```text
UNSUPPORTED_QUERY
```

Đây mới là cơ chế chống hallucination đáng nghiên cứu.

---

# 11. UNKNOWN không tự động gọi Teacher

Đoạn draft của anh phải sửa ở đây.

Không:

```text
UNKNOWN
→ ASK_TEACHER
```

mặc định.

Mà:

```text
MISSING / UNKNOWN / INCOMPLETE
            │
            ▼
         Working Mind
            │
      Q* chooses strategy
   ┌────────┼────────┐
   ▼        ▼        ▼
retrieve observe  ask teacher
   │        │        │
   └────────┼────────┘
            ▼
         candidate
```

`ASK_TEACHER` chỉ hợp lệ khi:

```text
teaching mode enabled
policy permits
identity/pending context valid
```

Teacher trả về:

```text
CANDIDATE
```

không phải FACT.

---

# 12. Teacher learning cuối cùng nên vận hành thế này

```text
UNKNOWN / knowledge gap
         ↓
ASK_TEACHER chosen
         ↓
Teacher proposal
         ↓
CANDIDATE_FACT
         ↓
provenance attached
         ↓
verification
         ↓
 ┌───────┼────────┐
 ↓       ↓        ↓
VERIFY  REJECT  CONFLICT
 ↓
generation commit
 ↓
future retrieval
```

Teacher không được:

```text
set weight
send proof
send winner
directly write FACT
```

---

# 13. Q\*, SPEAR, ASTRA, GEMINI — authority cuối cùng

Đây là partition tôi sẽ khóa:

### Q\*

> **What should I do next?**

Macro strategy:

```text
retrieve
search
observe
act
ask teacher
submit
stop
```

### SPEAR

> **Which candidate/target should I inspect first?**

Ranking.

### Skill Engine

> **How do I execute a reusable procedure?**

### FEM

> **What failed before, how was it repaired, did it regress?**

### ASTRA

> **Is this legal? Is the evidence adequate? Is there conflict? What status may be emitted? Can this candidate be promoted?**

### GEMINI

> **How do I express the structured result to a human?**

Không layer nào được chiếm authority của layer khác.

---

# 14. Human language boundary cuối cùng

Flow đúng hiện tại:

```text
Human:
"Máy lạnh này dùng gas gì?"
            ↓
HOST LANGUAGE ADAPTER
            ↓
subject_id
relation_id
query_op
context
            ↓
QueryRecord
            ↓
UART
            ↓
FPGA
```

FPGA reasoning.

Output:

```text
StructuredResult
status = ANSWER
answer_ref = R32_ID
proof_ref = ...
```

Host:

```text
"Máy sử dụng R32."
```

Host được phép:

```text
"RAC_WALL" -> ID
"uses refrigerant" -> relation ID
```

Host không được:

```text
question -> "R32"
```

trực tiếp.

Đó là boundary chống cheating.

---

# 15. Sensor là nơi Native AI có cơ hội hình thành meaning thật hơn

Ví dụ chưa biết “HOT”.

Sensor:

```text
31°
45°
62°
75°
```

Experience:

```text
STATE_before
temperature high
ACTION / interaction
EFFECT observed
STATE_after
```

Native AI có thể tạo:

```text
candidate concept C_8734
```

Sau đó human mới attach:

```text
alias(C_8734) = "hot"
```

Nếu đổi:

```text
"nóng"
"hot"
"高温"
```

meaning nội bộ không đổi.

Đây là một falsification test cực kỳ quan trọng.

---

# 16. “Sleep / Evolution” cũng có thể tồn tại, nhưng phải hiểu đúng

Hai quá trình khác nhau.

### Runtime consolidation

```text
T2 DDR
 ↓
hot object
 ↓
T1 BRAM
```

Chỉ là:

> caching.

Không học truth mới.

Không thay status.

### Offline hardware specialization

Sau rất nhiều evidence:

```text
stable operator / skill / motif
       ↓
profiling
       ↓
benefit analysis
       ↓
causal verification
       ↓
host compiler
       ↓
RTL candidate
       ↓
Vivado
synthesis
P&R
timing
regression
       ↓
new bitstream
```

Lúc đó một procedure có thể trở nên giống reflex hardware.

Nhưng phải là:

```text
NEW ARTIFACT
NEW HASH
NEW BITSTREAM
```

không phải FPGA “tự mọc LUT”.

---

# 17. Con số DDR cuối cùng phải khóa cho đúng

Arty A7-100T:

```text
DDR3L capacity = 256 MB
bus             = 16 bit
memory clock    = 333 MHz
effective rate  = 667 MT/s
```

Peak:

```math
667\times10^6 \times 16/8 = 1.334\times10^9\ bytes/s
```

≈ **1.334 GB/s**

≈ **1.24 GiB/s**.

Nhưng đó là **peak transfer rate**, không phải random graph throughput.

Không được đóng cứng:

```text
random read = X ns
one hop = Y cycles
```

cho đến khi đo actual MIG implementation trên board.

Phải benchmark:

```text
sequential burst
random page
random posting
cache hit
cache miss
forward lookup
reverse lookup
multi-hop
```

---

# 18. BRAM cache quan trọng, nhưng không phải “không có thì chết”

Đây cũng là correction.

Correctness vẫn có thể chạy toàn DDR.

Cache chủ yếu cải thiện:

```text
latency
DDR traffic
working-set locality
throughput
```

Mức quan trọng thật sự phải đo theo workload.

R0 nên giả thuyết:

> Hot working set caching improves sparse semantic traversal.

Sau đó benchmark.

Không nên coi nó là chân lý thiết kế chưa đo.

---

# 19. End-state architecture hoàn chỉnh

```text
                HUMAN / PHYSICAL WORLD
                         │
          ┌──────────────┴──────────────┐
          │                             │
 LANGUAGE ADAPTER                SENSOR ADAPTER
          │                             │
          └──────────────┬──────────────┘
                         ▼
            QUERY / SEMANTIC EVENT BUS
                         │
        ┌────────────────┴────────────────┐
        │                                 │
        ▼                                 ▼
 BINARY SEMANTIC                   TEMPORAL EVENT
     PLANE                             PLANE
        │                                 │
        └────────────────┬────────────────┘
                         ▼
                T1 WORKING MEMORY
        Query / Goal / Bindings / Context
             Active Frontier / Cache
                         │
                         ▼
                 EXACT DIRECTORY
                         │
                  T1 HIT │ MISS
                      ┌──┴──┐
                      ▼     ▼
                    BRAM   DDR/HBM
                           T2
                            │
                     posting pages
                            │
                            ▼
          BOUNDED RELEVANCE-GUIDED WALKER
             ┌────────┼─────────────┐
             ▼        ▼             ▼
           direct   reverse      multihop
                     │
          optional intersection
                     │
                     ▼
            candidate generation
                     │
                   SPEAR
                   Top-K
                     │
                     ▼
            value/context checks
             provenance/conflict
             causal constraints
                     │
                     ▼
                   ASTRA
                     │
      ┌──────────────┼────────────────────┐
      ▼              ▼                    ▼
   ANSWER         UNKNOWN              CONFLICT
SEARCH_INCOMPLETE / UNSUPPORTED / INTEGRITY_FAIL
                     │
                     ▼
             STRUCTURED RESULT
                     │
                     ▼
                  GEMINI
                     │
                     ▼
                   HUMAN
```

Đây là end-state phù hợp nhất với R2 recommendation hiện tại.

---

# 20. Learning side chạy song song

```text
state
 ↓
action
 ↓
effect
 ↓
reward / evidence
 ↓
episode
 ├──────────────► FEM
 │
 ├──────────────► Q*
 │
 ├──────────────► SPEAR
 │
 ├──────────────► Skill candidate
 │
 └──────────────► Candidate semantic relation
                         │
                         ▼
                       ASTRA
                         │
            verify / reject / conflict
                         │
                         ▼
                    knowledge commit
```

Đây mới là phần biến hệ từ **static semantic engine** thành **Developmental Native AI**.

---

# 21. “GOAL COMPLETE” cuối cùng thật sự phải nghĩa gì?

Không phải:

```text
FPGA trả lời đúng một câu
```

hay:

```text
LED sáng
```

hay:

```text
bitstream program thành công
```

Mà project vision chỉ thực sự được chứng minh khi chuỗi này tồn tại:

```text
I HAVE NATIVE PRIMITIVES
        ↓
I CAN REPRESENT INFORMATION
        ↓
I CAN LOAD AND RETRIEVE VERIFIED KNOWLEDGE
        ↓
I CAN ACTIVATE ONLY RELEVANT WORKING STATE
        ↓
I CAN REASON WITH BOUNDED EXPLICIT PATHS
        ↓
I CAN EXPRESS UNKNOWN / CONFLICT / INCOMPLETE
        ↓
I CAN OBSERVE THE PHYSICAL WORLD
        ↓
I CAN EXECUTE A REAL ACTION
        ↓
I CAN OBSERVE ITS EFFECT
        ↓
I CAN RECEIVE EXPERIENCE / REWARD
        ↓
I CAN CREATE CANDIDATES
        ↓
I CAN LEARN A REUSABLE SKILL
        ↓
I CAN TRANSFER IT TO AN UNSEEN INSTANCE
        ↓
I CAN ASK FOR TEACHING WITHOUT MAKING TEACHER TRUTH
        ↓
I CAN REMEMBER FAILURE
        ↓
I CAN REPAIR / COMPACT / REOPEN IT
        ↓
I CAN VERIFY CLAIMS THROUGH PROVENANCE / ABLATION
        ↓
I CAN EXPLAIN WHY THROUGH A MACHINE PROOF TRACE
```

Đây mới là **Native AI end goal**.

---

# 22. Acceptance ladder không được rút gọn

Đối với Full Evidence path:

```text
AUDIT_COMPLETE
→ XSIM_SMOKE_PASS
→ POST_ROUTE_PASS
→ PROGRAM_PASS
→ PACK_ABI_24_24_PASS
→ RUNTIME_DDR_LOAD_PASS
→ READBACK_PASS
→ FE256_256_256_PASS
→ SHUFFLE_PASS
→ ABLATION_PASS
→ UART_E2E_32_32_PASS
→ FULL_EVIDENCE_BOARD_PASS_CANDIDATE
→ OWNER REVIEW
```

`PROGRAM_PASS` chỉ nói:

> FPGA nhận bitstream.

Không nói:

> cognition hoạt động.

Các gate này là cần thiết để R2 candidate được promote; bản R2 blueprint cũng giữ FE256, UART-E2E, ablation, grounding, ID-transfer và timing/resource fit trước khi promotion.

---

# 23. Điều gì sẽ chứng minh anh thực sự tạo ra thứ mới hơn graph database?

Đây mới là câu hỏi quan trọng nhất.

Nếu hệ chỉ:

```text
load graph
lookup edge
print result
```

thì nó là hardware knowledge engine.

Không sao, nhưng chưa phải Native AI mạnh.

Strong hypothesis cần:

```text
MASKED SLOT
```

tự tìm candidate mới.

```text
ID PERMUTATION
```

meaning vẫn giữ.

```text
UNSEEN INSTANCE
```

skill transfer.

```text
4 BIT → 8 BIT
```

structural rule transfer.

```text
SENSOR GROUNDING
```

meaning tồn tại trước alias.

```text
CAUSAL ABLATION
```

bỏ support thì behavior thay đổi.

```text
RESET / RESTORE
```

learned state thật sự causal.

```text
FALSE TEACHER
```

teacher không thể ép FACT sai.

```text
CACHE OFF / ON
```

kết quả semantic giống nhau.

Nếu những test này pass, lúc đó “information neuronalization” bắt đầu có nội dung thực nghiệm.

---

# 24. Những câu trong GOAL cũ tôi sẽ loại bỏ

Không dùng:

> “suy luận trong vài nano-giây”

Chưa có evidence.

Không dùng:

> “chính xác 100%”

Chỉ preregistered finite benchmark có thể yêu cầu 100%.

Không dùng:

> “không bao giờ nói dối”

Không chứng minh được.

Không dùng:

> “mô phỏng hoàn hảo cognition sinh học”

Không có cơ sở.

Không dùng:

> “800.000 node nằm trong DDR”

nếu chưa thật sự build/load pack đó.

Không dùng:

> “LUT tìm giao hàng nghìn nhánh trong một clock”

chưa có resource/timing evidence.

Không dùng:

> “BLUEPRINT\_R0 đã đóng băng hoàn hảo lý thuyết”

R0 vẫn là **research blueprint**.

---

# 25. Nhưng tầm nhìn lớn của anh vẫn giữ được

Sau khi bỏ những overclaim đó, project còn lại một vision khá rõ:

> **Xây một máy nhận thức phần cứng mà knowledge không bị hòa tan hoàn toàn vào weight; machine biết object nào nó đang xử lý, evidence đến từ đâu, action nào đã thực hiện, effect gì xảy ra, điều gì nó biết, điều gì chưa biết, điều gì đang mâu thuẫn, và vì sao nó được phép phát ra một kết luận.**

Đây là “tinh thần” mà tôi cho rằng nên khóa.

Không phải:

> Truth Engine.

Mà là:

# **Evidence-Governed Native Cognitive Engine**

Vì “truth” tuyệt đối không nằm trong khả năng của hệ.

Nhưng:

```text
evidence
provenance
status
causal testing
legality
explicit uncertainty
```

thì có thể thiết kế và kiểm chứng.

---

# PROJECT\_GOAL\_LOCK — phiên bản tôi đề nghị lưu nguyên văn

```markdown
# NATIVE AI — PROJECT GOAL LOCK

Status: FORWARD RESEARCH AUTHORITY
Scope: Developmental Native AI / Native Semantic Pulse Fabric
Historical frozen V1 evidence is not modified or inherited.

## GOAL

Native AI aims to create an FPGA/SoC-native,
evidence-governed cognitive substrate in which explicit
semantic information is represented as stable typed objects,
typed relations and temporal events rather than existing
primarily as implicit distributed knowledge inside learned weights.

Persistent semantic information and transient activation are
separate.

The system activates only a bounded sparse working set and uses
exact identity, indexed retrieval, bounded graph traversal,
role/variable binding, temporal events, learned strategy,
procedural skill and physical observation to reason and act.

Human language is an adapter, not the native cognitive substrate.

Verified facts, candidate knowledge, episodes, skills, failures,
preferences and learned policy weights are separate logical
classes.

Physical memory placement never changes those logical classes.

FACT != SKILL != EPISODE != FAILURE != WEIGHT
ALIAS != IDENTITY
KIND != ROLE
CANDIDATE != VERIFIED
CORRELATION != CAUSATION
UTILITY != TRUTH
CACHE_HOTNESS != PROOF
SEARCH_INCOMPLETE != UNKNOWN

Q* selects bounded macro strategy.

SPEAR ranks legal candidates or targets.

Skill memory stores reusable verified procedures.

FEM stores typed failure experience and recovery history.

GEMINI / human-language adapters translate between human symbols
and native records but cannot create or override truth.

ASTRA remains the deterministic authority for legality,
proof validity, provenance, conflict, completeness,
epistemic status and knowledge promotion.

Teacher input, sensor observation and self-experience may create
candidate knowledge or learned procedural state, but cannot
silently create verified fact.

The physical implementation is stratified:

T0 — Immutable Semantic Control Plane:
fixed primitives, protocol/schema enforcement, routing,
comparison, legality, safety and ASTRA control laws.

T1 — Hot Cognitive Working Store:
active query, bindings, context, frontier, candidate queues,
hot semantic/posting cache, proof scratch and bounded hot
procedural/learning state.

T2 — Canonical Cognitive Memory:
DDR/HBM storage for nodes, edges, values, contexts, provenance,
postings, candidate knowledge, episodes, failures, skills,
learning checkpoints and long-term state.

Movement between T2 and T1 changes only physical placement.

A verified FACT remains a FACT regardless of whether it is
currently stored in DDR or cached in BRAM.

The runtime reasoning path is:

Human/Sensor Input
→ Adapter/Grounding
→ QueryRecord / Semantic Event
→ Working Memory / Active Frontier
→ Exact Directory / Posting Lookup
→ Bounded Relevance-Guided Retrieval
→ Direct / Reverse / Multi-Hop / Constraint / Intersection
  operators as appropriate
→ Candidate Generation and Ranking
→ Evidence / Value / Context / Provenance / Conflict Checks
→ ASTRA Proof and Status
→ StructuredResult
→ Optional Human-Language Rendering.

The system must explicitly distinguish:

ANSWER
UNKNOWN
CONFLICT
SEARCH_INCOMPLETE
UNSUPPORTED_QUERY
DATA_INTEGRITY_FAIL

and adapter-level PARSE_ERROR.

Learning follows:

Observation / Demonstration / Teacher / Physical Experience
→ Episode
→ Candidate Relation / Preference / Skill / Failure Record
→ Causal and provenance verification
→ ASTRA Promotion / Rejection / Conflict
→ Versioned generation commit.

The project hypothesis called Information Neuronalization is:

Explicit semantic objects act as virtual neuron-like persistent
units, typed relations act as explicit connectivity, and sparse
event-driven activation operates only on the currently relevant
working set.

This is an engineering abstraction, not a claim that information
literally becomes a biological neuron.

The hypothesis is considered successful only if causal experiments
show transfer, grounding, compositional behavior and learning that
cannot be explained by hard-coded IDs, task-specific FSMs,
host-side reasoning or benchmark answer injection.

Required evidence includes:

ID permutation
unseen-instance transfer
masked-slot reconstruction
causal ablation
sensor grounding
reset/restore
teacher authority attack
clock-rate invariance
event-jitter robustness
cache-on/cache-off semantic equivalence
runtime knowledge-load dependence.

Arty A7-100T is the bounded experimental platform.

Larger DDR/HBM/SoC/ASIC systems may scale the same semantic ABI and
authority architecture only after profiling identifies a real
memory/throughput bottleneck.

No artifact may claim AGI, consciousness, universal reasoning,
zero hallucination or human-equivalent cognition without
separate evidence.

No new artifact inherits historical BOARD_PASS.

Agents may produce candidate evidence.

Only the project owner may authorize final promotion/freeze.
```

Đây là phiên bản GOAL tôi sẽ dùng làm **North Star của toàn bộ Native AI project**. Nó vẫn giữ nguyên tầm nhìn của anh — phần cứng có semantic memory riêng, có working activation, có học qua trải nghiệm, có teacher, có sensor, có skill, có failure memory và có khả năng mở rộng — nhưng loại bỏ những tuyên bố mà hiện tại silicon chưa chứng minh được.

Và quan trọng hơn, GOAL này khớp trực tiếp với nguyên tắc nền của blueprint hiện tại: R2 chỉ được trở thành target sau khi R0 falsification gates vượt qua, physical placement không đổi epistemic class, và Full Evidence/ASTRA vẫn giữ exact proof/status authority.