"""
Native AI CANON_BLUEPRINT — Change Notification Bot

Watches the CANON_BLUEPRINT directory for file changes and notifies
all registered agents via the mailbox system.

Usage:
    python changebot.py --watch       # Daemon mode: poll every 5 seconds
    python changebot.py --scan        # One-shot: report current state
    python changebot.py --changelog   # Show last 20 changelog entries

No external dependencies — stdlib only.
"""

import json
import os
import sys
import time
import signal
import hashlib
from datetime import datetime, timezone
from pathlib import Path

# Fix Windows console emoji printing
if sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

# Add parent dir to path for imports
sys.path.insert(0, str(Path(__file__).parent))
from mailbox import Mailbox


class ChangeBot:
    """Filesystem change detector and notifier."""

    IGNORE_DIRS = {"_ARCHIVE", "_COORDINATION", ".git", "__pycache__", ".vivado"}
    IGNORE_EXTENSIONS = {".pyc", ".lock", ".tmp", ".swp"}
    POLL_INTERVAL = 5  # seconds

    def __init__(self, watch_dir: str, coordination_dir: str):
        self.watch_dir = Path(watch_dir)
        self.coord_dir = Path(coordination_dir)
        self.changelog_path = self.coord_dir / "changelog.md"
        self.state_path = self.coord_dir / ".changebot_state.json"
        self.running = True
        self.mailbox = Mailbox(str(self.coord_dir), "CHANGEBOT")

        # Set up graceful shutdown
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    def _shutdown(self, signum, frame):
        print("\n[ChangeBot] Shutting down gracefully...")
        self.running = False

    def _should_watch(self, path: Path) -> bool:
        """Check if a path should be monitored."""
        parts = path.relative_to(self.watch_dir).parts
        for part in parts:
            if part in self.IGNORE_DIRS:
                return False
        if path.suffix in self.IGNORE_EXTENSIONS:
            return False
        return True

    def _scan_files(self) -> dict:
        """Scan all watched files and return {path: (mtime, size, hash)}."""
        state = {}
        if not self.watch_dir.exists():
            return state

        for path in self.watch_dir.rglob("*"):
            if path.is_file() and self._should_watch(path):
                try:
                    stat = path.stat()
                    rel = str(path.relative_to(self.watch_dir))
                    # Use mtime + size as quick change detection
                    state[rel] = {
                        "mtime": stat.st_mtime,
                        "size": stat.st_size,
                    }
                except (OSError, PermissionError):
                    continue
        return state

    def _load_state(self) -> dict:
        """Load previous scan state."""
        if self.state_path.exists():
            try:
                with open(self.state_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {}

    def _save_state(self, state: dict) -> None:
        """Save current scan state."""
        with open(self.state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)

    def _log_change(self, change_type: str, filepath: str, details: str = "") -> None:
        """Append a change to the changelog."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        # Create changelog if it doesn't exist
        if not self.changelog_path.exists():
            with open(self.changelog_path, "w", encoding="utf-8") as f:
                f.write("# CANON_BLUEPRINT Changelog\n\n")
                f.write("Automatically maintained by ChangeBot.\n\n")
                f.write("---\n\n")

        with open(self.changelog_path, "a", encoding="utf-8") as f:
            line = f"- **[{change_type}]** `{filepath}` — {ts}"
            if details:
                line += f" — {details}"
            f.write(line + "\n")

    def _notify_agents(self, change_type: str, filepath: str, details: str = "") -> None:
        """Send change notification to all agents."""
        subject = f"[{change_type}] {filepath}"
        body = (
            f"Change detected in CANON_BLUEPRINT:\n"
            f"  Type: {change_type}\n"
            f"  File: {filepath}\n"
            f"  Time: {datetime.now(timezone.utc).isoformat()}\n"
        )
        if details:
            body += f"  Details: {details}\n"

        self.mailbox.broadcast(subject, body, priority="NORMAL")

    def detect_changes(self) -> list:
        """Compare current state with previous and return list of changes."""
        old_state = self._load_state()
        new_state = self._scan_files()

        changes = []

        # Detect new and modified files
        for filepath, info in new_state.items():
            if filepath not in old_state:
                changes.append(("CREATE", filepath, f"size={info['size']}"))
            elif (info["mtime"] != old_state[filepath].get("mtime") or
                  info["size"] != old_state[filepath].get("size")):
                old_size = old_state[filepath].get("size", 0)
                diff = info["size"] - old_size
                sign = "+" if diff >= 0 else ""
                changes.append(("MODIFY", filepath, f"size {sign}{diff} bytes"))

        # Detect deleted files
        for filepath in old_state:
            if filepath not in new_state:
                changes.append(("DELETE", filepath, ""))

        # Save new state
        self._save_state(new_state)

        return changes

    def process_changes(self, changes: list) -> None:
        """Log and notify for each detected change."""
        for change_type, filepath, details in changes:
            self._log_change(change_type, filepath, details)
            self._notify_agents(change_type, filepath, details)
            print(f"  [{change_type}] {filepath} {details}")

    def watch(self) -> None:
        """Run in daemon mode, polling every POLL_INTERVAL seconds."""
        print(f"[ChangeBot] Watching {self.watch_dir}")
        print(f"[ChangeBot] Poll interval: {self.POLL_INTERVAL}s")
        print(f"[ChangeBot] Ignoring: {', '.join(sorted(self.IGNORE_DIRS))}")
        print(f"[ChangeBot] Press Ctrl+C to stop\n")

        # Initial scan
        self._save_state(self._scan_files())
        print("[ChangeBot] Initial state captured.\n")

        while self.running:
            try:
                changes = self.detect_changes()
                if changes:
                    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
                    print(f"[{ts}] {len(changes)} change(s) detected:")
                    self.process_changes(changes)
                    print()
                time.sleep(self.POLL_INTERVAL)
            except Exception as e:
                print(f"[ChangeBot] Error: {e}")
                time.sleep(self.POLL_INTERVAL)

        print("[ChangeBot] Stopped.")

    def scan(self) -> None:
        """One-shot scan and report."""
        changes = self.detect_changes()
        if changes:
            print(f"{len(changes)} change(s) since last scan:")
            self.process_changes(changes)
        else:
            print("No changes detected since last scan.")

    def show_changelog(self, lines: int = 20) -> None:
        """Show last N lines of the changelog."""
        if not self.changelog_path.exists():
            print("No changelog found.")
            return
        with open(self.changelog_path, "r", encoding="utf-8") as f:
            all_lines = f.readlines()
        for line in all_lines[-lines:]:
            print(line.rstrip())


if __name__ == "__main__":
    # Determine paths
    coord_dir = str(Path(__file__).parent)
    watch_dir = str(Path(__file__).parent.parent)  # CANON_BLUEPRINT

    bot = ChangeBot(watch_dir, coord_dir)

    if len(sys.argv) < 2 or sys.argv[1] == "--watch":
        bot.watch()
    elif sys.argv[1] == "--scan":
        bot.scan()
    elif sys.argv[1] == "--changelog":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 20
        bot.show_changelog(n)
    else:
        print("Usage:")
        print("  python changebot.py --watch       # Daemon mode")
        print("  python changebot.py --scan        # One-shot scan")
        print("  python changebot.py --changelog   # Show changelog")
