"""
Native AI CANON_BLUEPRINT — Agent Coordination Mailbox

File-based inter-agent messaging system using JSON files.
No external dependencies — stdlib only.

Usage:
    from mailbox import Mailbox
    mb = Mailbox(base_dir="_COORDINATION", agent_id="AGENT_A")
    mb.send("AGENT_B", "Update", "I finished §01")
    messages = mb.check_inbox()
    mb.broadcast("Announcement", "Schema lock updated")
"""

import json
import os
import time
import hashlib
from datetime import datetime, timezone
from pathlib import Path


class Mailbox:
    """File-based inter-agent messaging system."""

    def __init__(self, base_dir: str, agent_id: str):
        self.base_dir = Path(base_dir)
        self.agent_id = agent_id
        self.mailbox_dir = self.base_dir / "mailbox"
        self.inbox_dir = self.mailbox_dir / agent_id / "inbox"
        self.read_dir = self.mailbox_dir / agent_id / "inbox" / "read"
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        self.read_dir.mkdir(parents=True, exist_ok=True)

    def _make_filename(self, subject: str, sender: str) -> str:
        """Create a unique filename for a message."""
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        slug = subject.lower().replace(" ", "_")[:30]
        # Add hash to ensure uniqueness
        uid = hashlib.md5(f"{ts}{sender}{subject}{time.time_ns()}".encode()).hexdigest()[:6]
        return f"{ts}_{sender}_{slug}_{uid}.json"

    def send(self, to_agent: str, subject: str, body: str, priority: str = "NORMAL") -> str:
        """Send a message to a specific agent's inbox.

        Args:
            to_agent: Target agent ID (e.g., 'AGENT_A')
            subject: Message subject
            body: Message body
            priority: CRITICAL / HIGH / NORMAL / LOW

        Returns:
            Path to the created message file.
        """
        if priority not in ("CRITICAL", "HIGH", "NORMAL", "LOW"):
            raise ValueError(f"Invalid priority: {priority}. Use CRITICAL/HIGH/NORMAL/LOW")

        target_inbox = self.mailbox_dir / to_agent / "inbox"
        target_inbox.mkdir(parents=True, exist_ok=True)

        message = {
            "sender": self.agent_id,
            "to": to_agent,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "priority": priority,
            "subject": subject,
            "body": body,
        }

        filename = self._make_filename(subject, self.agent_id)
        filepath = target_inbox / filename

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(message, f, indent=2, ensure_ascii=False)

        return str(filepath)

    def broadcast(self, subject: str, body: str, priority: str = "NORMAL") -> list:
        """Send a message to ALL registered agents except self.

        Returns:
            List of paths to created message files.
        """
        sent = []
        if not self.mailbox_dir.exists():
            return sent

        for agent_dir in self.mailbox_dir.iterdir():
            if agent_dir.is_dir() and agent_dir.name != self.agent_id:
                path = self.send(agent_dir.name, subject, body, priority)
                sent.append(path)
        return sent

    def check_inbox(self) -> list:
        """Return list of unread messages sorted by priority then timestamp.

        Returns:
            List of dicts with 'file' and 'message' keys.
        """
        priority_order = {"CRITICAL": 0, "HIGH": 1, "NORMAL": 2, "LOW": 3}
        messages = []

        if not self.inbox_dir.exists():
            return messages

        for f in self.inbox_dir.iterdir():
            if f.is_file() and f.suffix == ".json":
                try:
                    with open(f, "r", encoding="utf-8") as fp:
                        msg = json.load(fp)
                    messages.append({"file": str(f), "message": msg})
                except (json.JSONDecodeError, IOError):
                    continue

        messages.sort(key=lambda m: (
            priority_order.get(m["message"].get("priority", "NORMAL"), 2),
            m["message"].get("timestamp", ""),
        ))
        return messages

    def mark_read(self, message_file: str) -> None:
        """Move a message to the read subfolder."""
        src = Path(message_file)
        if src.exists():
            dst = self.read_dir / src.name
            src.rename(dst)

    def count_unread(self) -> int:
        """Count unread messages."""
        if not self.inbox_dir.exists():
            return 0
        return sum(1 for f in self.inbox_dir.iterdir()
                   if f.is_file() and f.suffix == ".json")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python mailbox.py <agent_id> [check|send <to> <subject> <body>|broadcast <subject> <body>]")
        sys.exit(1)

    agent_id = sys.argv[1]
    base = str(Path(__file__).parent)
    mb = Mailbox(base, agent_id)

    if len(sys.argv) == 2 or sys.argv[2] == "check":
        messages = mb.check_inbox()
        if not messages:
            print(f"[{agent_id}] No unread messages.")
        else:
            print(f"[{agent_id}] {len(messages)} unread message(s):")
            for m in messages:
                msg = m["message"]
                print(f"  [{msg['priority']}] From: {msg['sender']} | {msg['subject']}")
                print(f"    {msg['body'][:100]}")
                print(f"    @ {msg['timestamp']}")
                print()

    elif sys.argv[2] == "send" and len(sys.argv) >= 6:
        path = mb.send(sys.argv[3], sys.argv[4], " ".join(sys.argv[5:]))
        print(f"Message sent: {path}")

    elif sys.argv[2] == "broadcast" and len(sys.argv) >= 5:
        paths = mb.broadcast(sys.argv[3], " ".join(sys.argv[4:]))
        print(f"Broadcast sent to {len(paths)} agent(s)")

    else:
        print("Usage: python mailbox.py <agent_id> [check|send <to> <subject> <body>|broadcast <subject> <body>]")
