"""
Native AI CANON_BLUEPRINT — Agent Startup Script

Run this at the beginning of every agent session to:
1. Register in the agent registry
2. Check inbox for pending messages
3. Check resource locks for conflicts
4. Print document ownership summary
5. Show recent changelog entries

Usage:
    python agent_startup.py --agent-id AGENT_A --role "Architecture Lead"

No external dependencies — stdlib only.
"""

import json
import sys
import argparse
from datetime import datetime, timezone
from pathlib import Path

# Fix Windows console emoji printing
if sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

# Add parent dir to path for imports
sys.path.insert(0, str(Path(__file__).parent))
from mailbox import Mailbox
from resource_lock import ResourceLock


COORDINATION_DIR = Path(__file__).parent
REGISTRY_PATH = COORDINATION_DIR / "registry.json"
SCHEMA_LOCK_PATH = COORDINATION_DIR / "schema_lock.json"
CHANGELOG_PATH = COORDINATION_DIR / "changelog.md"


def load_registry() -> dict:
    if REGISTRY_PATH.exists():
        try:
            with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"agents": {}, "last_updated": None}


def save_registry(registry: dict) -> None:
    registry["last_updated"] = datetime.now(timezone.utc).isoformat()
    with open(REGISTRY_PATH, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2, ensure_ascii=False)


def register_agent(agent_id: str, role: str) -> None:
    """Register agent in the registry."""
    registry = load_registry()
    registry["agents"][agent_id] = {
        "role": role,
        "status": "active",
        "current_task": None,
        "resources_held": [],
        "registered_at": datetime.now(timezone.utc).isoformat(),
        "last_seen": datetime.now(timezone.utc).isoformat(),
    }
    save_registry(registry)
    print(f"✓ Registered as {agent_id} ({role})")


def check_inbox(agent_id: str) -> None:
    """Check for unread messages."""
    mb = Mailbox(str(COORDINATION_DIR), agent_id)
    messages = mb.check_inbox()
    count = len(messages)

    if count == 0:
        print("✓ Inbox: empty")
    else:
        print(f"⚠ Inbox: {count} unread message(s):")
        for m in messages:
            msg = m["message"]
            print(f"  [{msg['priority']}] From: {msg['sender']} — {msg['subject']}")
            body_preview = msg.get("body", "")[:80]
            if body_preview:
                print(f"    {body_preview}")


def check_locks() -> None:
    """Check resource lock status."""
    rl = ResourceLock(str(COORDINATION_DIR))
    status = rl.status()

    print("\n📎 Resource Locks:")
    has_conflict = False
    for resource, info in status.items():
        holders = info["holders"]
        lock_type = info["lock_type"]
        if holders:
            holder_str = ", ".join(h["agent_id"] for h in holders)
            print(f"  [{lock_type}] {resource}: HELD by {holder_str}")
            has_conflict = True
        else:
            print(f"  [{lock_type}] {resource}: ✓ available")

    stale = rl.check_stale()
    if stale:
        print("\n  ⚠ Stale locks (past expected release time):")
        for resource, holder in stale:
            print(f"    {resource} held by {holder['agent_id']} since {holder['timestamp']}")

    if not has_conflict:
        print("  ✓ All resources available")


def show_ownership(agent_id: str) -> None:
    """Show document ownership for this agent."""
    if not SCHEMA_LOCK_PATH.exists():
        print("\n⚠ schema_lock.json not found — cannot show ownership")
        return

    with open(SCHEMA_LOCK_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)

    docs = schema.get("documents", {})
    owned = []
    readonly = []

    for doc_name, info in sorted(docs.items()):
        if info.get("owner") == agent_id:
            owned.append(doc_name)
        else:
            readonly.append((doc_name, info.get("owner", "?")))

    print(f"\n📄 Document Ownership for {agent_id}:")
    print(f"  OWNED (read-write): {len(owned)} documents")
    for d in owned:
        print(f"    ✏️  {d}")

    print(f"  READ-ONLY: {len(readonly)} documents")
    for d, owner in readonly:
        print(f"    🔒 {d} (owner: {owner})")


def show_changelog(lines: int = 10) -> None:
    """Show recent changelog entries."""
    if not CHANGELOG_PATH.exists():
        print("\n📝 Changelog: no entries yet")
        return

    with open(CHANGELOG_PATH, "r", encoding="utf-8") as f:
        all_lines = [l.rstrip() for l in f.readlines() if l.strip().startswith("-")]

    recent = all_lines[-lines:] if all_lines else []

    print(f"\n📝 Recent Changes ({len(recent)} of {len(all_lines)}):")
    if recent:
        for line in recent:
            print(f"  {line}")
    else:
        print("  (none)")


def show_other_agents(agent_id: str) -> None:
    """Show other registered agents."""
    registry = load_registry()
    others = {k: v for k, v in registry.get("agents", {}).items() if k != agent_id}

    if others:
        print(f"\n👥 Other Registered Agents:")
        for aid, info in others.items():
            status = info.get("status", "unknown")
            role = info.get("role", "unknown")
            last_seen = info.get("last_seen", "?")
            print(f"  {aid} ({role}) — {status} — last seen {last_seen}")
    else:
        print(f"\n👥 No other agents registered yet")


def main():
    parser = argparse.ArgumentParser(description="Native AI Agent Startup")
    parser.add_argument("--agent-id", required=True, help="Agent identifier (e.g., AGENT_A)")
    parser.add_argument("--role", required=True, help="Agent role description")
    args = parser.parse_args()

    agent_id = args.agent_id
    role = args.role

    print("=" * 60)
    print(f"  NATIVE AI — Agent Startup")
    print(f"  {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print("=" * 60)
    print()

    # 1. Register
    register_agent(agent_id, role)

    # 2. Check inbox
    check_inbox(agent_id)

    # 3. Check locks
    check_locks()

    # 4. Show ownership
    show_ownership(agent_id)

    # 5. Show changelog
    show_changelog()

    # 6. Show other agents
    show_other_agents(agent_id)

    print()
    print("=" * 60)
    print("  Startup complete. Begin work on your owned documents.")
    print("  Run: python _COORDINATION/changebot.py --watch")
    print("  (if you are Agent D or the first agent to start)")
    print("=" * 60)


if __name__ == "__main__":
    main()
