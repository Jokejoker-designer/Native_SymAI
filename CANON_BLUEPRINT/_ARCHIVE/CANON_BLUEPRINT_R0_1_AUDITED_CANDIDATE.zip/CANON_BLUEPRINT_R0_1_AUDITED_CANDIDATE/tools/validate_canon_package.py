#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

# ABI arithmetic
layout=json.loads((ROOT/'schemas/abi_r0_1_layout.json').read_text(encoding='utf-8'))
for name,rec in layout['records'].items():
    total=sum(bits for _,bits in rec['fields'])
    if total != rec['total_bits']:
        errors.append(f"{name}: fields={total} declared={rec['total_bits']}")
mt=sum(n for _,n in layout['manifest_header']['fields'])
if mt != layout['manifest_header']['total_bytes']:
    errors.append(f"ManifestHeader: fields={mt} declared={layout['manifest_header']['total_bytes']}")

# YAML-like frontmatter key presence for numbered docs + GOAL
required={'version','owner','status','category','last_modified'}
for p in sorted(ROOT.glob('*.md')):
    if p.name in {'README.md','COORDINATION_STATUS.md','ARCHIVE_CONFLICT_INDEX.md'}:
        continue
    text=p.read_text(encoding='utf-8')
    if not text.startswith('---\n'):
        errors.append(f"{p.name}: missing frontmatter")
        continue
    block=text.split('---\n',2)[1]
    keys=set(re.findall(r'^([A-Za-z0-9_]+):',block,re.M))
    miss=required-keys
    if miss: errors.append(f"{p.name}: missing frontmatter keys {sorted(miss)}")

# Cross-reference existence
numfiles={m.group(1):p for p in ROOT.glob('*.md') if (m:=re.match(r'^(\d{2})_',p.name))}
headings={p.name:[m.group(1).strip() for m in re.finditer(r'^#{1,6}\s+(.+)$',p.read_text(encoding='utf-8'),re.M)] for p in ROOT.glob('*.md')}
for p in ROOT.glob('*.md'):
    text=p.read_text(encoding='utf-8')
    for m in re.finditer(r'\[§(\d{2})(?:\.(\d+))?\]',text):
        num,sec=m.group(1),m.group(2)
        if num not in numfiles:
            errors.append(f"{p.name}: missing target {m.group(0)}")
            continue
        if sec:
            target=numfiles[num]
            prefixes=(f"{int(num)}.{sec}",f"{num}.{sec}")
            if not any(h.startswith(prefixes) for h in headings[target.name]):
                errors.append(f"{p.name}: missing target section {m.group(0)} in {target.name}")

# Forbidden stale definitions outside archive/audit history
checks={
  '24 nodes, 24 edges':'PACK_ABI must mean integrity cases, not record count',
  '256-node graph':'FE256 must mean 256 cases, not graph size',
  '133 MB/s':'DDR factor-of-10 stale value'
}
for p in ROOT.glob('*.md'):
    if p.name in {'AUDIT_REPORT_R0_1.md','R0_1_ERRATA_AND_PATCHES.md','ARCHIVE_CONFLICT_INDEX.md'}:
        continue
    text=p.read_text(encoding='utf-8')
    for needle,msg in checks.items():
        if needle in text:
            errors.append(f"{p.name}: stale phrase {needle!r}: {msg}")

if errors:
    print('VALIDATION_FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('VALIDATION_PASS')
print('ABI records:', ', '.join(f"{k}={v['total_bits']}b" for k,v in layout['records'].items()))
print('ManifestHeader:', layout['manifest_header']['total_bytes'],'bytes')
