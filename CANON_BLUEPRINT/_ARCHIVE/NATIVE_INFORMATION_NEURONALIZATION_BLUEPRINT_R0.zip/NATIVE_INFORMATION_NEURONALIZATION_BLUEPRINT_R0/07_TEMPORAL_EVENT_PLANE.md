# 07 — TEMPORAL EVENT PLANE

## 7.1 Purpose

The Temporal Event Plane represents change, ordering, physical interaction and experience. It complements rather than replaces exact semantic identity.

## 7.2 Event

Candidate event classes:

```text
OBSERVATION
STATE_ENTER
STATE_EXIT
ACTION_ISSUED
ACTION_COMMITTED
EFFECT_OBSERVED
REWARD
FAILURE
TEACHER_DEMO
QUERY_EVENT
RESULT_EVENT
```

## 7.3 State transition

Core experience pattern:

```text
STATE_BEFORE
  -> ACTION
  -> OBSERVED_EFFECT
  -> STATE_AFTER
  -> REWARD / STATUS
```

This is the preferred teaching substrate for physical skills.

## 7.4 Duration

Duration is explicit data, not inferred from arbitrary FPGA cycles. Use logical timestamps/intervals and, when required, calibrated physical-time units.

## 7.5 BEFORE / AFTER

`BEFORE` and `AFTER` are semantic temporal relations derived from explicit event ordering, not from text word order.

## 7.6 Action/effect

An action does not imply its expected effect occurred. Physical/readback evidence must record:

```text
expected_effect
observed_effect
verification_status
```

## 7.7 Reward

Reward is scalar evaluation tied to exact episode/step identity. Reward is not truth and cannot directly set learner weights supplied by a teacher.

## 7.8 Jitter doctrine

**[FALSIFIED]** jitter is not semantic alphabet. Inject timing variation in verification; require same semantic result when logical ordering is unchanged.
