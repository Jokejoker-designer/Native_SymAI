# 30 — RISK REGISTER

| ID | Risk | Class | Severity | Detection | Mitigation |
|---|---|---|---|---|---|
| S-01 | IDs/aliases mistaken for meaning | semantic | Critical | alias rename / ID permutation | separate ID/KIND/ROLE/alias |
| S-02 | ontology becomes English grammar | semantic | High | multilingual parity | normalize language at adapter |
| S-03 | explicit graph is just hand-coded expert system | semantic | Critical | unseen composition/instance tests | reusable primitives + transfer gates |
| M-01 | DDR random-access wall | memory | High | bytes/query, latency distribution | cache/postings/paging; HBM only after profiling |
| M-02 | hub node explosion | memory | High | adjacency overflow tests | paged adjacency + incomplete status |
| M-03 | cache thrashing | memory | High | hit/miss by cache class | admission control + segmentation |
| M-04 | cache stale generation | memory | Critical | generation-ablation test | exact generation tags + atomic switch |
| P-01 | event drop/duplicate | protocol | Critical | seq/CRC assertions | FIFO/backpressure/retry identity |
| P-02 | logical time coupled to cycles | protocol | High | clock-rate invariance | explicit logical tick |
| P-03 | retry causes double semantic commit | protocol | Critical | duplicate frame test | idempotent transaction IDs |
| L-01 | unexecuted action receives credit | learning | Critical | trajectory audit | executed-action-only updates |
| L-02 | teacher injects semantic winner | learning | Critical | authority attack | scalar/demo candidate only |
| L-03 | correlation promoted to cause | learning | Critical | intervention/ablation | ASTRA causal ladder |
| A-01 | Q*/SPEAR score overrides truth | authority | Critical | high-score invalid candidate attack | ASTRA veto/status authority |
| A-02 | GEMINI changes status | authority | Critical | conflict/unknown rendering test | structured result locked before text |
| A-03 | host becomes hidden reasoner | authority | Critical | log QueryRecord + host code audit | host alias/codec only |
| T-01 | accidental multiplier/logic replication | timing | High | OOC resources | shared/sequential arithmetic |
| T-02 | unconstrained CDC fake timing pass | timing | Critical | clock interaction report | explicit CDC constraints/handshakes |
| T-03 | proof path timing dominates query | timing | Medium/High | separate retrieval/proof cycles | bounded proof object / pipelining |
| G-01 | sensor grounding fails | cognition | Critical | alias-before/after, unseen sensor | permit hybrid perception if required |
| G-02 | no advantage vs ordinary graph engine | project | Critical | fair CPU/FPGA graph baseline | falsify strong claim if no added value |
| E-01 | no energy benefit | project | High | measured joules/query | keep claim narrow; optimize only measured bottleneck |

## 30.1 Stop rules

After repeated repair attempts in the same causal class without progress, stop patching and require architecture review. Never rescue a benchmark by changing gold/thresholds or by adding case-specific semantic rules.
