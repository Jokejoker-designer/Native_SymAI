# 14 — LEARNING ARCHITECTURE

## 14.1 Separation of learning state

Learning state is not stored inside verified fact records. Maintain independent stores for:

```text
CANDIDATE_RELATION
PREFERENCE
Q_WEIGHT
SPEAR_WEIGHT
SKILL_STATE
FAILURE_PROTOTYPE
AFFORDANCE_STATS
```

## 14.2 Candidate relations

Observation/co-occurrence may create or update candidate relations with explicit status and provenance. Candidate relation lifecycle:

```text
OBSERVED
 -> CANDIDATE
 -> VERIFIED or REJECTED or CONFLICTED
```

No frequency threshold directly yields `VERIFIED`.

## 14.3 Preference

Utility/preference may summarize successful action choice under context. It never changes truth of facts.

## 14.4 Q*

Q* remains macro strategy selection:

```text
RETRIEVE
SEARCH
OBSERVE
ACT
ASK_TEACHER
SUBMIT
STOP
```

Use bounded fixed-point learner with executed-action-only credit and deterministic EXAM mode.

## 14.5 SPEAR

SPEAR ranks targets/candidates inside the macro action. It cannot promote truth or change legality.

## 14.6 Promotion

Promotion to verified knowledge requires ASTRA proof rules, provenance and conflict checks. A teacher statement, reward, repeated observation or high score is insufficient on its own.

## 14.7 Reset/restore causal standard

A learned claim must support:

```text
W0/S0/K0 -> behavior A
train      -> W1/S1/K1 -> behavior B
reset      -> A returns
restore    -> B returns
```

If not, causal learning is not established.
