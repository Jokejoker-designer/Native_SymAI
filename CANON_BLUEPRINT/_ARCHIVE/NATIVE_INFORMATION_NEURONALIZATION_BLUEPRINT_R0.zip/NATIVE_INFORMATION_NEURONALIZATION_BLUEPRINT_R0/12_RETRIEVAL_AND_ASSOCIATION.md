# 12 — RETRIEVAL AND ASSOCIATION

## 12.1 Exact directory

Primary truth-path lookup is exact. Recommended flow:

```text
semantic_id
 -> hash / index
 -> candidate bucket/page
 -> full-key verify
 -> canonical record pointer
```

Hash collisions never become semantic matches.

## 12.2 Forward postings

Forward index maps `(subject, relation, context bucket)` to edge/posting pages. Keep one source-of-truth compiler for page format and an independent verifier for pack equivalence.

## 12.3 Reverse postings

Reverse index is a first-class capability, not “scan all forward edges.” Reverse lookup must be independently benchmarked and causally disabled in ablation tests.

## 12.4 Bounded posting pages

High-degree nodes use paged adjacency. Silent truncation is forbidden. If traversal cannot exhaust a hub within budget, status becomes `SEARCH_INCOMPLETE`.

## 12.5 Optional CAM

CAM/BCAM may accelerate:

- hot ID directory;
- alias dictionary;
- visited set;
- exact compact key lookup.

Do not implement one giant full-width CAM when hash-indexed exact tags are cheaper.

## 12.6 Optional HDC/VSA sidecar

**[HYPOTHESIS]** approximate associative memory may propose Top-K native IDs for ambiguous/sensor-derived inputs:

```text
ambiguous input
 -> HDC candidate proposal
 -> exact native IDs
 -> NCG retrieval
 -> ASTRA proof
```

The sidecar cannot return final truth or proof.

## 12.7 Cache policy

Prefer admission control + segmented hot stores rather than pure LRU. Hotness should consider frequency, recency, retrieval cost, proof-path utility, graph locality, payload size and volatility.
