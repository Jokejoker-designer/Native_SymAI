# 00 — EXECUTIVE SUMMARY

## 0.1 Decision

**[SUPPORTED]** Native Semantic Pulse Fabric (NSPF) is technically plausible as a **bounded cognitive substrate** in which explicit semantic units, typed relations, bindings, events and state transitions are persistent/activatable objects, while only a sparse working frontier is active at a time.

The defensible proposition is **not** “replace neural networks.” The target is narrower:

> Use exact, typed, addressable information as the persistent cognitive substrate; use event-driven sparse activation and bounded retrieval/reasoning over that substrate; reserve dense/approximate neural computation for optional perception, association or language boundaries when it provides measurable benefit.

## 0.2 Architecture in one diagram

```text
HUMAN / SENSOR / ENVIRONMENT
            |
            v
ADAPTERS / EVENT ABSTRACTION
            |
   +--------+--------+
   |                 |
   v                 v
BINARY SEMANTIC   TEMPORAL EVENT
PLANE             PLANE
ID/REL/VALUE      EVENT/STATE/ACTION
CTX/PROV          TICK/DURATION/REWARD
   |                 |
   +--------+--------+
            v
      WORKING MIND
 NCG + Q* + SPEAR + SKILL + FEM
            |
            v
          ASTRA
 proof / legality / status / promotion
            |
            v
    STRUCTURED RESULT
            |
            v
 HUMAN LANGUAGE ADAPTER
```

## 0.3 What is novel enough to test

**[ESTABLISHED]** No individual ingredient is new: semantic networks, CAM, sparse distributed memory, VSA/HDC, production systems, external neural memory, event-driven neuromorphic routing, graph accelerators and event sensors all provide relevant precedent.

**[HYPOTHESIS]** The potentially distinctive combination is:

```text
exact typed semantic identity
+ explicit context/provenance
+ verified/candidate/episode/skill separation
+ sparse logical-event activation
+ causal proof/status authority
+ FPGA-native bounded graph/event execution
+ causal falsification by ablation/permutation/reset/clock invariance
```

Novelty must be treated as **unproven** until a dedicated patent/literature search is completed.

## 0.4 Design choices locked in R0

- Semantic identity uses stable `ID`; grammatical/contextual use is carried by `ROLE`.
- `KIND`, `CLASS`, `STATE`, `ROLE`, `STATUS` are independent fields.
- Human strings are aliases, not hardware identity.
- 6W1H may be a compact query-operator algebra, not an English ontology.
- Logical semantic ticks carry order/time meaning; FPGA clock rate does not.
- Jitter is verification noise unless represented explicitly as data.
- Long-term knowledge is virtualized in DDR/HBM; one circuit per semantic unit is rejected.
- BRAM is a managed hot/working store, not a truth tier.
- Promotion across memory tiers changes **placement**, not epistemic status.
- ASTRA remains the authority for legality, proof, conflict, completeness and promotion.

## 0.5 Recommended implementation sequence

1. Keep Full Evidence FE256 as the verified static semantic baseline.
2. Implement a fixed semantic/event ABI and a bounded active-frontier engine.
3. Run `NSPF-X0`: role binding + masked slot + timing perturbation + causal ablation.
4. Only after X0 passes, integrate sensor grounding and parameterized skill transfer.
5. Scale graph size only after DDR access, cache behavior and proof cost are measured.
6. Move to HBM only when profiling shows memory bandwidth/parallel random access is the actual bottleneck.

## 0.6 Critical success criteria

NSPF earns a stronger claim only if behavior survives representational perturbations while remaining causally dependent on its true support:

```text
ID permutation      -> semantics preserved
alias replacement   -> semantics preserved
physical timing gap -> semantics preserved
support edge removal-> answer changes
reset W0            -> baseline returns
restore W1          -> learned behavior returns
```

If the system instead reduces to a manually curated knowledge graph plus task-specific FSMs, or hidden host/LLM reasoning is required for every useful composition, the strong “information neuronalization” hypothesis has failed.
