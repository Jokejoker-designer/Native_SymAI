# 15 — SENSOR GROUNDING

## 15.1 Objective

Test whether stable native concepts can form from physical effect/observation before a human alias is attached.

## 15.2 Raw event

Physical input enters as typed events with source capability, calibrated value, logical time, quality/error flags and provenance.

## 15.3 Feature/event abstraction

R0 should use deterministic or simple bounded feature extraction first:

```text
raw sample
 -> calibrated value
 -> threshold/range/event bucket
 -> state transition
```

Do not claim concept formation merely because a host preprocessing model labeled the event.

## 15.4 Native concept formation

Candidate native concept may arise when repeated observations share a stable effect/state pattern. Creation must be bounded and versioned; do not create a node for every cycle.

## 15.5 Alias attachment

Teaching sequence:

```text
unlabeled capability/state
 -> observe and act
 -> build effect relations
 -> stable internal SELF_ID
 -> attach HUMAN_ALIAS later
```

The causal structure must remain valid after alias rename or multilingual alias replacement.

## 15.6 Grounding falsification

Claim fails if:

- behavior depends on exact text alias;
- renamed alias destroys learned action/effect relation;
- host supplies hidden semantic label before native interaction;
- raw ID rather than class/effect structure explains transfer.

## 15.7 Perception boundary

**[SUPPORTED]** If raw vision/audio requires a dense or neuromorphic front end, that is compatible with NSPF. Perception may output candidate semantic events; exact identity/proof remains downstream.
