# 04 — SEMANTIC UNIT MODEL

## 4.1 SemanticUnit

**[HYPOTHESIS]** Minimal canonical record:

```text
SemanticUnit {
  id              u32
  generation      u16
  namespace_id    u16
  kind            u8
  state           u8
  flags           u16
  class_id        u32
  fwd_index_ref   u32
  rev_index_ref   u32
  alias_ref       u32
  provenance_ref  u32
}
```

R0 may pack this to a 32-byte `NodeRecord`.

## 4.2 ID

- stable within `(namespace, generation)` contract;
- never inferred from human alias text;
- never silently reused while old references remain live;
- exact comparison after any hash-index lookup.

## 4.3 KIND

Candidate kinds:

```text
ENTITY AGENT ACTION STATE PROPERTY EVENT VALUE TIME LOCATION
GOAL SKILL CAPABILITY SENSOR SYMBOL FAILURE PROOF_REF
```

KIND is orthogonal to ROLE.

## 4.4 CLASS

CLASS groups transferable properties/capabilities. Examples:

```text
DIGITAL_OUT
TEMPERATURE_SENSOR
REFRIGERANT
FOOD
ROTARY_ACTUATOR
```

Transfer tests should preserve CLASS/effect schema while changing raw instance IDs.

## 4.5 STATE

Do not overload one field. Separate lifecycle/epistemic state where necessary:

```text
record_lifecycle: ACTIVE / RETIRED / TOMBSTONE
knowledge_status: CANDIDATE / VERIFIED / CONFLICTED / REJECTED
skill_status: CANDIDATE / LEARNED / VERIFIED / STABLE / REOPENED
```

## 4.6 Alias separation

```text
SELF_ID = stable native identity
HUMAN_ALIAS = optional, multilingual, versionable
SEMANTIC_ROLE = learned/contextual relation, not the alias
```

Renaming an alias must not invalidate causal/action knowledge.

## 4.7 Namespaces and generations

Recommended native identity tuple:

```text
(namespace_id, generation, local_id)
```

Cross-generation stale references must reject or explicitly migrate. Checkpoints bind schema, pack, policy, skill and capability generations.
