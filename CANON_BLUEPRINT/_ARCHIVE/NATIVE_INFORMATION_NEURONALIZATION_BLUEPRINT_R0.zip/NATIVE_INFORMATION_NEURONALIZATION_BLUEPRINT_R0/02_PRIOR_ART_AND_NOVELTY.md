# 02 — PRIOR ART AND NOVELTY

## 2.1 Research rule

**[ESTABLISHED]** No novelty claim is allowed from this blueprint alone. This file maps technical neighborhoods that must be compared before any patent or research novelty statement.

## 2.2 Sparse distributed memory

Kanerva-style Sparse Distributed Memory establishes that high-dimensional patterns can be stored/recalled from distributed locations using partial/noisy cues. Relevance: associative fallback and similarity. Limitation: exact typed provenance and deterministic factual identity are not native.

## 2.3 CAM / associative memory

FPGA CAM/BCAM prior art establishes exact key-to-value lookup in hardware and RAM-backed associative structures. Relevance: hot semantic directory, alias map, visited set. Limitation: CAM solves lookup, not graph reasoning, binding, causality or proof.

## 2.4 VSA / HDC

Vector Symbolic Architectures and Hyperdimensional Computing establish distributed high-dimensional representation, binding, bundling and noise tolerance. Relevance: optional candidate association or compositional sidecar. Limitation: approximate similarity must not become truth authority.

## 2.5 SPA / Nengo

Semantic Pointer Architecture and Nengo/Spaun establish that structured cognitive representations, working memory and action selection can coexist in neural/spiking systems. NSPF must compare variable binding and compositionality against SPA rather than assume the territory is new.

## 2.6 NTM / DNC

Neural Turing Machines and Differentiable Neural Computers establish learned access to external memory. Relevance: controller + memory separation. Difference: NSPF favors exact typed lookup/status/provenance over differentiable addressing for the truth path.

## 2.7 ACT-R / Soar

Production/cognitive architectures establish explicit working memory, long-term memory, goals, procedures and rules. Risk: NSPF can collapse into a re-labeled expert system. Required counter-evidence: unseen-instance transfer, ID permutation, masked composition and sensor grounding.

## 2.8 SNN / neuromorphic

TrueNorth, Loihi, SpiNNaker and related systems establish sparse event routing, local state and online learning. Relevance: event fabric and scalable routing. Difference: NSPF events carry typed semantic references and explicit proof/status rather than spike-only meaning.

## 2.9 Graph accelerators

FPGP, Graphicionado, ScalaBFS and related designs establish bounded frontier traversal, memory-system specialization and HBM scaling for irregular graphs. Relevance: NCG/Full Evidence walker. Limitation: memory randomness, hub vertices and proof construction remain bottlenecks.

## 2.10 Event sensors

Dynamic/event-based vision sensors demonstrate sparse asynchronous physical events. Relevance: sensor input to Temporal Event Plane. Limitation: raw events are not semantic concepts; grounding/abstraction remains a separate problem.

## 2.11 Patent map — representative technical zones

The research report identified representative prior art around:

- FPGA-integrated CAM and RAM-backed CAM engines;
- distributed event-based neuromorphic computation;
- external neural memory;
- VSA/associative lookup mechanisms.

**[SUPPORTED]** A formal novelty/FTO study should search claims around the *combination* of typed semantic records + event activation + proof authority + hardware caching/specialization, not merely the individual ingredients.

## 2.12 Novelty boundary

Not novel by itself:

```text
concepts stored in memory
events sent as pulses
graph traversal on FPGA
associative lookup
vector binding
working vs long-term memory
```

Potential research contribution:

```text
exact semantic object model
+ explicit epistemic classes
+ dual semantic/event planes
+ sparse activation
+ FPGA causal proof boundary
+ hardware placement stratification
+ causal promotion/falsification discipline
```

## 2.13 Reference anchors from the Deep Research report

- Vaswani et al. — *Attention Is All You Need*.
- Lewis et al. — Retrieval-Augmented Generation.
- Kanerva — Sparse Distributed Memory.
- Kleyko et al. — VSA/HDC frameworks and hardware.
- Eliasmith/Nengo/Spaun — Semantic Pointer Architecture.
- Graves et al. — NTM and DNC.
- ACT-R and Soar official cognitive-architecture literature.
- IBM TrueNorth; Intel Loihi; SpiNNaker.
- FPGP, Graphicionado, ScalaBFS.
- AMD HBM/DDR BCAM.
- Harnad — Symbol Grounding Problem.
- Schölkopf et al. — Causal Representation Learning.
