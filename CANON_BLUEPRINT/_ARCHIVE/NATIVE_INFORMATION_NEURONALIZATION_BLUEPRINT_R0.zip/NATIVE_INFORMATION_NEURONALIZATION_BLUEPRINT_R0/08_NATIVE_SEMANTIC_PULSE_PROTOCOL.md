# 08 — NATIVE SEMANTIC PULSE PROTOCOL

## 8.1 Logical ticks

Every semantic event carries `logical_tick` and `sequence_id`. Physical cycle count is debug/performance metadata only.

## 8.2 Event packet R0

Recommended **192-bit** packet:

```text
191:184 event_type
183:176 semantic_kind
175:168 role
167:160 flags
159:128 semantic_id
127:96  value_or_ref
95:64   logical_tick
63:32   context_id
31:16   source_id
15:0    sequence_id
```

## 8.3 Ordering

Ordering rules:

- same stream: monotonically increasing `sequence_id`;
- logical meaning uses `logical_tick` + frame/transaction identity;
- delayed physical arrival is legal if protocol ordering remains valid;
- reordering requires explicit reorder buffer or rejection.

## 8.4 Flow control

Use `VALID/READY` style interfaces internally. Required invariant:

```text
valid && !ready -> payload stable
```

Backpressure must be observable; FIFO overflow cannot silently become `UNKNOWN`.

## 8.5 CRC

UART/external packet framing includes magic, ABI version, type, length, sequence and CRC. Memory pages additionally carry page integrity metadata.

## 8.6 Retry / duplicate handling

Each externally committed transaction binds:

```text
session_id + txn_id + generation + sequence_id
```

Duplicate data/reward/query frames are detected explicitly. Retry may resend transport data but may not double-commit semantic updates.

## 8.7 Status on protocol fault

Examples:

```text
CRC_ERROR
STALE_GENERATION
DUPLICATE_FRAME
FIFO_OVERFLOW
SEQ_GAP
UNSUPPORTED_ABI
```

Protocol faults must not be rendered as semantic `UNKNOWN`.
