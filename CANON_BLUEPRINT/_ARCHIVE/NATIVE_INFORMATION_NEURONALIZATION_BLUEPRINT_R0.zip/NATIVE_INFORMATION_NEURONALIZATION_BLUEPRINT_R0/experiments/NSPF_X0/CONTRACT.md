# NSPF-X0 CONTRACT — LOGICAL EVENT + MASKED SLOT + CAUSAL ABLATION

## Primary causal question

Can an explicit `KIND/ROLE/ID` frame resolve one missing slot from semantic support, remain invariant to legal physical timing perturbation, and lose the answer when the support is removed?

## Preregistered cases

```text
X0_A_BASE       Pack A -> ANSWER(EAT)
X0_A_GAPS       Pack A -> ANSWER(EAT)
X0_A_JITTER     Pack A -> ANSWER(EAT)
X0_ROLE_SWAP    Pack A -> must not ANSWER(EAT)
X0_B_ABLATED    Pack B -> UNKNOWN
```

## Hard failures

```text
DROPPED_EVENT != 0
DUPLICATED_EVENT != 0
TXN_MISMATCH != 0
UNEXPLAINED_ANSWER != 0
Ablation does not change result
```

## Allowed claim

Only: bounded role binding + timing invariance + semantic support dependence is evidenced for the preregistered X0 workload.
