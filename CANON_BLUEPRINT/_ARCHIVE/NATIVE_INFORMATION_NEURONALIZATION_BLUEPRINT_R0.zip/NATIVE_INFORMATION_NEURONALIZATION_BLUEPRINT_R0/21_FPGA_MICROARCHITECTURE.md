# 21 — FPGA MICROARCHITECTURE

## 21.1 Recommended Arty R0 pipeline

```text
UART / Host Adapter
      |
      v
Frame RX + CRC + Seq
      |
      +------> Knowledge Pack Loader
      |              |
      |              v
      |           MIG DDR3
      |
      v
Query/Event Decoder
      |
      v
Working Memory / Bindings
      |
      v
Exact Directory + Cache
      |
      v
Graph Walker / Constraint Resolver
      |
      +----> Q* / SPEAR / Skill lane when enabled
      |
      v
ASTRA Proof/Status Engine
      |
      v
Structured Result TX
```

## 21.2 Loader

Loader accepts manifest + pages, verifies ABI/schema/integrity at the implemented level, performs readback sentinels and atomically activates generation.

## 21.3 MIG

All semantic DDR traffic is blocked until MIG calibration completes. Centralize byte/beat conversion and 128-bit packing rules. Do not assume command/data ready coincide.

## 21.4 Cache

BRAM cache holds hot directory/postings/records and active frontier. Use shadow-bank fill + atomic activation for promoted pages/entries.

## 21.5 Graph walker

R0 walker is one bounded engine with:

- forward/reverse posting access;
- max depth/budget;
- visited filter;
- relation/context masks;
- proof parent tracking;
- explicit overflow/incomplete status.

## 21.6 Event router

Single on-chip router first. Route semantic packets to frame assembler, working mind, learning lane and result/proof lane with VALID/READY backpressure.

## 21.7 Proof engine

Proof builder records machine edges/rules and provenance refs while walking. Language is not generated in RTL.

## 21.8 Optional hardware profiler

Sideband access profiler may track frequency/recency/miss cost for cache admission without stalling the main path. Count-Min Sketch or compact counters are candidate mechanisms; cache score remains placement-only metadata.

## 21.9 Deferred features

Do not include in Arty MVP unless a benchmark justifies them:

```text
multi-walker NoC
HBM-specific banking
full CAM fabric
HDC vector sidecar
DFX semantic specialization
large dense neural blocks
```
