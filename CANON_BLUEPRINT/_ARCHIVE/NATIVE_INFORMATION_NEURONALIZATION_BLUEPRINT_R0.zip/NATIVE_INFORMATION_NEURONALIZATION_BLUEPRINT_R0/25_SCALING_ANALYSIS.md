# 25 — SCALING ANALYSIS

## 25.1 Hub nodes

High-degree concepts can dominate traversal. Required design:

- paged adjacency;
- explicit page count;
- bounded hot Top-K only as optimization;
- no silent truncation;
- `SEARCH_INCOMPLETE` if budget cannot cover required evidence.

## 25.2 Cache hit rate

Track separately:

```text
directory hit
posting hit
edge/value hit
proof/provenance hit
skill hit
```

A single aggregate hit rate hides the true bottleneck.

## 25.3 Cache thrashing controls

R0 candidates:

- admission policy based on frequency/recency/miss cost;
- segmented hot stores;
- pinned active-frontier entries;
- context-aware eviction;
- aging;
- subgraph-aware prefetch only when measured useful.

## 25.4 Graph partition

Future HBM/large FPGA partition key candidates:

```text
semantic namespace
relation class
community/locality partition
source/context partition
hash partition with replication of hot hubs
```

Partitioning must preserve proof/provenance references and generation coherence.

## 25.5 Multi-walker

Only introduce multiple walkers after single-walker profiling shows memory-level parallelism is available. Required issues:

- duplicate frontier suppression;
- visited-set ownership;
- DDR/HBM bank conflicts;
- proof merge;
- deterministic transaction ordering where required.

## 25.6 HBM

HBM R2 scale target:

```text
many memory channels
 -> graph partitions
 -> walker per channel/group
 -> semantic-event merge
 -> ASTRA proof/status merge
```

Peak bandwidth is an upper bound, not expected random-graph performance.

## 25.7 ASIC/SoC long range

**[SPECULATIVE]** A mature implementation could use distributed local semantic caches + packet routers + persistent semantic memory. This is not an Arty requirement and should not distort R0 verification.
