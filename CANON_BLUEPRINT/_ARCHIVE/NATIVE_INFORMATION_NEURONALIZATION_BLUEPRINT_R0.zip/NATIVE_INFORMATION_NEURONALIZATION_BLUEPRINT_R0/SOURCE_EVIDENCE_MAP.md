# SOURCE AND EVIDENCE MAP

## User-supplied research basis

Primary design basis:

- `Native Semantic Pulse Fabric — Neuronalizing Information Instead of Neuronalizing Computation.md`

Project-context sources used to preserve existing authority and implementation boundaries:

- `00_README_NATIVE_AI_DEVELOPMENTAL_HARDWARE_R1.md`
- `01_MASTER_ARCHITECTURE_AND_BRAIN_PARTITION.md`
- `02_MEMORY_ARCHITECTURE_BRAM_DDR.md`
- `03_ALGORITHMS_AND_LEARNING.md`
- `04_FAILURE_EXPERIENCE_MEMORY_AND_COMPACTION.md`
- `05_SKILL_OPTIONS_AND_BOARD_TEACHING.md`
- `06_SIMPLE_MILESTONE_ROADMAP.md`
- `07_VERIFICATION_AND_CAUSAL_TESTS.md`
- `08_RTL_FAILURE_RISK_REGISTER.md`
- `09_IMPLEMENTATION_START_AND_LOCKED_DECISIONS.md`
- `NATIVE_AI_NATIVE_INFORMATION_FABRIC_R1/*`
- `NATIVE_AI_FULL_EVIDENCE_FE256_BENCHMARK_R1/*`

## Literature families carried over from the research report

The blueprint preserves the report's distinctions around:

- Transformer / retrieval-augmented baselines;
- Kanerva sparse distributed memory;
- CAM / BCAM associative lookup;
- VSA / HDC;
- Semantic Pointer Architecture / Nengo / Spaun;
- Neural Turing Machine / Differentiable Neural Computer;
- ACT-R / Soar;
- TrueNorth / Loihi / SpiNNaker;
- event-based sensors;
- FPGA graph accelerators such as FPGP, Graphicionado, ScalaBFS;
- symbol grounding and causal representation learning.

This package does not independently re-run the legal novelty search. `02_PRIOR_ART_AND_NOVELTY.md` therefore keeps novelty claims explicitly provisional.
