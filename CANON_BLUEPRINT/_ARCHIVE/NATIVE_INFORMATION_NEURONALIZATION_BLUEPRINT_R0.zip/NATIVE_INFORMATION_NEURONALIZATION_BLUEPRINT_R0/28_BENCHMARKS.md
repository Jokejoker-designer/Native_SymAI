# 28 — BENCHMARKS

## 28.1 FE256

FE256 remains the core acceptance benchmark for the verified static semantic plane. NSPF does not redefine it.

Required principles:

```text
256/256 explicit structured results
wrong answer = 0
false refusal = 0
EMPTY = 0
timeout = 0
txn mismatch = 0
context/identity leak = 0
proof/provenance valid where required
```

A partial score is `FAIL_PARTIAL`, not PASS.

## 28.2 FE-UART-E2E-32

Human-facing acceptance after FE256:

```text
human text
 -> host adapter
 -> native QueryRecord
 -> UART
 -> FPGA semantic path
 -> StructuredResult
 -> UART
 -> host renderer
```

32/32 semantic parity required with zero EMPTY/TIMEOUT/PARSE_DEADLOCK/TXN mismatch/status distortion.

## 28.3 Transfer tests

NSPF-specific transfer set:

- ID permutation;
- unseen equivalent capability instance;
- alias/language replacement;
- unseen initial state;
- unseen goal composition;
- 4->8->16 width transfer where primitive shortcut is disabled;
- masked-slot holdout composition.

## 28.4 Latency tests

Report distributions by case class:

```text
cache hit
DDR direct
reverse
multi-hop
hub/overflow
proof-heavy
```

Separate retrieval cycles from proof cycles and UART/adapter time.

## 28.5 Energy tests

Energy thesis is valid only with measured power/latency on fair hardware. Compare:

- FPGA NSPF;
- CPU indexed graph/reference;
- appropriate small neural/transformer baseline for the same bounded task where meaningful.

Report joules/query or energy/work unit; do not infer energy from “event-driven” terminology.

## 28.6 Order/ablation controls

Every benchmark family that claims semantic correctness should include shuffled order and causal ablation where technically meaningful.
