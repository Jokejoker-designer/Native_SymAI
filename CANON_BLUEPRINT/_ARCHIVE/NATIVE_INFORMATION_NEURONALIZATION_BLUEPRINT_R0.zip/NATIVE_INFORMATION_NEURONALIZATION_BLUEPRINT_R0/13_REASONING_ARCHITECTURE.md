# 13 — REASONING ARCHITECTURE

## 13.1 Scope

R0 reasoning is bounded, explicit and proof-producing. It is not unrestricted theorem proving.

## 13.2 Direct retrieval

```text
(subject, relation, context)
 -> exact forward posting
 -> edge/value
 -> proof step
 -> ASTRA status
```

## 13.3 Reverse retrieval

```text
(object/value, relation, context)
 -> reverse posting
 -> candidate subjects
 -> proof step
```

Reverse capability must not be synthesized by host-side inversion.

## 13.4 Bounded multi-hop

Recommended initial limits:

```text
max_depth = 4–6
frontier <= 16/32
step/search budget explicit
visited bounded
relation mask explicit
```

Any exhausted budget must remain visible as `SEARCH_INCOMPLETE`.

## 13.5 Constraint resolution

Frames may constrain:

- semantic kind/class;
- relation compatibility;
- context;
- value/range/unit;
- source/provenance requirements;
- temporal relation.

Constraint filtering can reduce the active candidate set before SPEAR ranking.

## 13.6 Missing slots

Missing slot workflow:

```text
MISSING_SLOT
 -> exact retrieval
 -> graph inference
 -> sensor/observation request
 -> execute experiment/skill
 -> ask teacher
 -> UNKNOWN / SEARCH_INCOMPLETE
```

Q* may choose the macro strategy. SPEAR may rank legal candidates. ASTRA decides whether a candidate is sufficiently supported.

## 13.7 No semantic shortcuts

Forbidden:

```text
if case_id == X -> answer Y
if query string matches -> return gold
materialize inverse edge only to evade reverse test
materialize derived fact only to evade required multi-hop
```
