# 06 — BINARY SEMANTIC PLANE

## 6.1 Purpose

The Binary Semantic Plane stores exact persistent semantic information. It is independent of natural-language strings and distinct from temporal activation.

## 6.2 Node

`NodeRecord` identifies a semantic unit, class, index pointers, alias/provenance references and generation.

Recommended R0 size: **32 bytes**.

## 6.3 Relation

`RelationRecord`/registry defines relation identity and constraints:

```text
relation_id
src_kind_mask
dst_kind_mask
directionality
context_policy
proof_rule
flags
```

Critical distinctions remain exact:

```text
CORRELATES_WITH != CAUSES
NAMED_AS != IS_A
ACHIEVES != PROVES
FAILED_AT != ILLEGAL
```

## 6.4 Edge

Recommended verified edge baseline:

```text
EdgeRecord {
  src_id          u32
  dst_id          u32
  relation_id     u16
  status          u8
  flags           u8
  context_ref     u32
  value_ref       u32
  provenance_ref  u32
  valid_from      u32
  valid_to        u32
}
```

Keep learned utility/counters outside verified fact edges.

## 6.5 Value

Typed values are first-class; never collapse them into entity ID zero.

```text
ValueRecord {
  value_type  u8
  flags       u8
  unit_id     u16
  lo          u32
  hi          u32
  aux_ref     u32
}
```

Supports scalar/range/enum/reference encodings.

## 6.6 Context

Context is explicit, versioned and composable. Examples: device model, environment, goal, time validity, measurement conditions.

## 6.7 Provenance

Provenance must survive caching and inference. Minimum fields:

```text
source_id
source_revision
location/span
content_digest/ref
acquisition_mode
```

## 6.8 Canonical separation

```text
VERIFIED_FACT store
CANDIDATE_FACT store
OBSERVATION store
EPISODE store
SKILL store
FAILURE store
POLICY_WEIGHT store
```

No implicit promotion across stores.
