# 01 — RESEARCH HYPOTHESIS

## 1.1 Information neuronalization definition

**[HYPOTHESIS]**

> **Information neuronalization** is the representation of explicit semantic units as individually addressable persistent computational objects; typed relations behave as semantic synapses; current cognition is a sparse activation/binding state over those objects; temporal experience is an ordered event stream; learning modifies candidate relations, skills, preferences and policy state without silently changing verified truth.

A semantic unit is virtual, not one physical neuron circuit:

```text
SemanticUnit := {ID, KIND, CLASS, STATE, FLAGS, INDEX_PTRS, PROVENANCE_REF}
SemanticEdge := {SRC, RELATION, DST/VALUE, CONTEXT, STATUS, PROVENANCE_REF}
Activation_t := sparse set of active IDs + bindings + frontier entries
```

## 1.2 Claims

**[SUPPORTED]** This architecture can plausibly provide:

- exact identities and typed relations;
- bounded sparse graph retrieval;
- deterministic provenance/proof paths;
- explicit epistemic states (`ANSWER`, `UNKNOWN`, `CONFLICT`, `SEARCH_INCOMPLETE`);
- incremental update of explicit knowledge without retraining a dense model;
- event-driven working memory over persistent semantic records;
- causal tests that can identify hidden shortcuts.

**[HYPOTHESIS]** It may additionally provide useful structural transfer, grounded concept formation and reusable skill induction. Those are experimental claims, not design truths.

## 1.3 Non-claims

This blueprint does **not** claim:

- AGI, consciousness or human-level cognition;
- that neural networks are unnecessary;
- that all perception can be solved symbolically;
- that graph traversal is intrinsically faster than Transformers;
- that binary representation itself creates intelligence;
- that 6W1H is a universal ontology;
- that event-driven operation automatically saves energy;
- that explicit semantics solve the symbol-grounding problem.

## 1.4 Baselines

### LLM baseline

**[ESTABLISHED]** Transformers and language models use learned parametric representations; retrieval-augmented systems add explicit non-parametric memory. The relevant comparison is therefore **weight-centric cognition vs explicit semantic memory**, not “LLM has no memory.”

### Graph baseline

**[ESTABLISHED]** Indexed graph databases and graph accelerators already provide explicit nodes/edges, postings, traversal and sometimes provenance. NSPF must show value beyond renaming a graph database “neurons.”

### Neuromorphic baseline

**[ESTABLISHED]** TrueNorth, Loihi and SpiNNaker show that sparse event-driven communication and time-multiplexed logical neurons can be efficient. They do not establish exact semantic identity/proof as a cognitive authority.

## 1.5 Falsifiable central hypothesis

NSPF is worth keeping only if, on bounded workloads, it demonstrates some combination of:

```text
lower incremental update cost
+ deterministic provenance
+ bounded causal reasoning
+ transfer across raw IDs/aliases
+ sparse memory-access advantage
+ sensor-grounded concept stability
```

versus a conventional indexed graph engine and a fair small-model baseline.
