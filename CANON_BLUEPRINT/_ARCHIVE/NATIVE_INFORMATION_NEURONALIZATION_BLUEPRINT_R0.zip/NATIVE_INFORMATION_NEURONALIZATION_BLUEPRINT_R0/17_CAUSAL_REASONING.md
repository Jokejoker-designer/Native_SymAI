# 17 — CAUSAL REASONING

## 17.1 Observation

Record only what is observed:

```text
ACTION_X executed
STATE_before
EFFECT_Y observed
STATE_after
```

Do not infer physical cause beyond evidence.

## 17.2 Correlation

Repeated co-occurrence may support `CORRELATES_WITH` or a candidate causal relation. Correlation is explicitly distinct from `CAUSES`.

## 17.3 Intervention

Causal promotion requires intervention where feasible:

```text
hold context approximately fixed
change action/candidate variable
observe effect distribution
```

## 17.4 Ablation

Remove or disable the purported support and rerun the same query/behavior. If outcome survives unchanged, investigate hidden duplicate support, stale cache, host injection or hard-coded logic.

## 17.5 Verified cause

Candidate ladder:

```text
OBSERVED_TOGETHER
 -> CORRELATES_WITH
 -> INTERVENTION_SUPPORTED
 -> CANDIDATE_CAUSES
 -> ASTRA proof gate
 -> VERIFIED_CAUSES
```

Not all domains allow strong causal verification; status must reflect uncertainty rather than force a cause label.

## 17.6 Causal proof object

Proof should reference intervention episodes, controls, context and effect observations. Natural-language explanation is derived from the proof, never the source of it.
