# 18 — SKILL AND PROCEDURE MEMORY

## 18.1 Primitive

Primitive is a deterministic capability/opcode supplied by the substrate:

```text
READ WRITE TOGGLE COMPARE PACK UNPACK MEM_READ MEM_WRITE UART_TX ...
```

## 18.2 Option / skill

A reusable skill contains:

```text
skill_id
version
goal_class
preconditions
capability_class_mask
max_steps
policy_or_sequence_ref
termination_schema
expected_effect_schema
cost statistics
status
```

## 18.3 Parameterized skill

Skills should reference capability classes/roles/parameters rather than literal IDs where possible.

Bad:

```text
WRITE LED3
```

Better:

```text
SET_STATUS_INDICATOR(target: DIGITAL_OUT with required effect)
```

## 18.4 Transfer

Train on capability instance A; exam on unseen instance B with same class/effect schema. ID permutation is mandatory to detect scripts.

## 18.5 Skill lifecycle

```text
CANDIDATE
 -> LEARNED
 -> VERIFIED
 -> STABLE
 -> COMPACTED
 -> REOPENED on regression
```

One positive reward cannot directly create a stable skill.

## 18.6 Procedure memory vs truth

A skill is procedural memory, not a verified proposition. `ACHIEVES` relations are context-conditioned utility/procedure relations unless separately proven as facts.
