# 16 — TEACHER AND ACTIVE LEARNING

## 16.1 Teacher modes

Supported modes:

```text
OBSERVE
DEMO
TRAIN
EXAM
```

DEMO provenance must remain separate from autonomous evidence.

## 16.2 Demonstrations

Teacher may provide explicit primitive/skill demonstrations. Demonstration creates trajectory/candidate skill evidence, not immediate stable skill truth.

## 16.3 Reward

Teacher may provide scalar reward tied to exact pending identity:

```text
session_id
txn_id
episode_id
step_id/generation
reward_value
crc
```

Teacher may not send weight deltas, hidden winner action, winner candidate or proof override.

## 16.4 Question to teacher

Active-learning macro action `ASK_TEACHER` is allowed only in teaching lanes. Its output is candidate information with source=`HUMAN_TEACHER`.

Suggested response classes:

```text
ALIAS
CANDIDATE_RELATION
GOAL
DEMONSTRATION
SCALAR_REWARD
CLARIFICATION
```

## 16.5 Authority boundary

```text
teacher proposal -> CANDIDATE
teacher alias    -> alias metadata
teacher reward   -> learner update eligibility
teacher proof override -> forbidden
```

ASTRA remains promotion authority.

## 16.6 Anti-parrot test

After teaching, remove/rephrase the original language cue and test equivalent native conditions. Success that requires verbatim teacher wording is not grounded learning.
