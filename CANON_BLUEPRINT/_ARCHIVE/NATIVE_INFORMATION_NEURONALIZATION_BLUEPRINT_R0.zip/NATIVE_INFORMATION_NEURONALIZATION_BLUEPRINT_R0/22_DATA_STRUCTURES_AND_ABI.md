# 22 — DATA STRUCTURES AND ABI

## 22.1 ABI rule

All binary layouts are versioned, endian-explicit, generated from one schema authority, and verified by an independent decoder/checker. Do not let the pack compiler and verifier share the same encode/decode helper if that would hide the same bug on both sides.

## 22.2 Core records

Recommended R0 sizes:

| Record | Size | Purpose |
|---|---:|---|
| `NodeRecord` | 32 B | semantic identity + indices |
| `EdgeRecord` | 32 B | typed verified/candidate relation |
| `PostingRecord` | 8 B | edge/neighbor reference |
| `ValueRecord` | 16 B | typed scalar/range/reference |
| `ContextRecord` | 16–32 B | contextual constraints |
| `ProvenanceRecord` | 32 B baseline | source/version/location/digest ref |
| `ProofHeader` | 16 B | proof identity/status |
| `ProofStep` | 16 B | edge/rule step |
| `SemanticEventPacket` | 24 B | 192-bit event packet |
| `QueryRecord` | 32 B | 256-bit native query |
| `StructuredResult` | 40 B candidate | semantic result + proof refs |

## 22.3 QueryRecord binary candidate

```text
magic                16
abi_version           8
flags                 8
txn_id               32
query_meta           16
subject_id           32
relation_id          16
object_or_constraint 32
context_id           32
value_or_constraint  32
search_budget        16
crc16                16
-----------------------
TOTAL               256 bits
```

`query_meta` packs query operator, direction, answer-kind hint and max hops.

## 22.4 StructuredResult candidate

```text
status           8
reason_code      8
answer_kind      8
flags            8
txn_id          32
answer_ref      32
value_lo        32
value_hi        32
unit_id         16
completeness     8
conflict_count   8
proof_ref       32
provenance_ref  32
context_ref     32
conflict_ref    32
```

If alignment requires a wider fixed word, pad explicitly and include a versioned length.

## 22.5 Manifest

Knowledge Pack manifest includes:

```text
magic
manifest_version
abi_version
schema_version
endianness
generation
record counts
region offsets/sizes
schema_sha256
content_sha256
compiler_abi_sha256
page_size
page_crc_scheme
manifest_crc
```

If FPGA hardware does not implement SHA-256, state the evidence level accurately, e.g. `HOST_SHA256_VERIFIED`, not a fake hardware hash claim.

## 22.6 Generations

Generation changes are atomic. Active state is never overwritten in place:

```text
write inactive
 -> integrity verify
 -> sentinel readback
 -> commit
 -> atomic active-generation flip
```

## 22.7 Compatibility

Compatibility matrix is explicit:

```text
ABI exact match required for binary record width/layout
schema major mismatch -> reject
schema minor compatible only if declared
unknown required flag -> reject
unknown optional flag -> ignore only if contract says so
```

## 22.8 Machine-readable schemas

This package includes:

- `schemas/query_record.schema.json`
- `schemas/structured_result.schema.json`
- `schemas/semantic_event.schema.json`
- `schemas/pack_manifest.schema.json`

These are design schemas, not proof that RTL exists.
