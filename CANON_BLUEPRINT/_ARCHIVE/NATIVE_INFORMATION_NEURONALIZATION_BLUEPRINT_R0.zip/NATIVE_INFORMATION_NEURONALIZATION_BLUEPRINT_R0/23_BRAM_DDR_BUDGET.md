# 23 — BRAM / DDR BUDGET

## 23.1 Physical baseline

**[ESTABLISHED from project research]** Arty A7-100T provides approximately 4,860 Kib (~607.5 KiB raw) block RAM and 256 MiB-class external DDR3L. Full integration must reserve BRAM for MIG-side buffers, protocol FIFOs, Working Mind, proof scratch and other logic.

## 23.2 Planning model

A conservative semantic-unit planning model from the research uses roughly **256 bytes per unit** when average edges, bidirectional postings and indexing/provenance overhead are included. This is a sizing hypothesis, not measured pack density.

| Scale | Approx footprint | Arty implication |
|---:|---:|---|
| 1k | ~0.244 MiB | can fit in BRAM only as a lab case, but wastes hot memory |
| 10k | ~2.44 MiB | DDR required |
| 100k | ~24.4 MiB | DDR comfortable; locality becomes key |
| 1M | ~244 MiB | near Arty DDR capacity before other state |
| 10M | ~2.38 GiB | HBM/server-class target |

## 23.3 Recommended Arty BRAM envelope

Initial target, to be validated by OOC synthesis:

```text
directory/node cache           4–8 BRAM36
forward/reverse posting cache  8–12
edge/value cache               4–8
frontier + visited             2–4
proof scratch                  2–4
bindings/working state         2–4
query/result/event FIFOs       2–4
skill/failure hot state        4–8
MIG-side buffering             8–16
--------------------------------------
preferred semantic subtotal    ~34–68 BRAM36
reserve                        >=20 BRAM36 if practical
```

Do not treat this as utilization evidence.

## 23.4 Cache directory sizing example

A 128-bit hot-directory entry:

```text
semantic_id      32
cache_addr       24
generation       16
semantic_class    8
epistemic_status  8
context_tag      16
payload_words     8
flags             8
integrity_tag     8
```

1024 entries require only ~16 KiB raw storage before RAM granularity overhead. This favors hash-indexed exact tags over a full parallel CAM.

## 23.5 DDR region candidate

Reuse the forward Developmental memory philosophy:

```text
manifest/checkpoint headers
lexicon/alias/skill metadata
exact directory + forward/reverse postings
nodes/edges/values/contexts/provenance
episodes + raw failures
compacted skills/failure/procedural memory
policy checkpoints + scratch
reserve/growth
```

No migration into frozen V1 memory maps without a separate gate.

## 23.6 HBM scale

HBM is a later scale target for multiple independent graph partitions/walkers. Capacity/bandwidth gains do not remove the need for bounded frontier, locality, proof-cost accounting and exact generation control.
