# 31 — WHAT WOULD FALSIFY THE PROJECT

The strong NSPF hypothesis is considered falsified or materially weakened if controlled experiments repeatedly show several of the following:

1. New domains require new hand-written semantic FSMs instead of reusable primitives/relations.
2. ID permutation destroys supposed concepts or skills.
3. Alias/language replacement destroys physical/semantic knowledge.
4. Masked-slot success disappears on novel composition even though the necessary relations exist.
5. Causal ablation leaves the same answer without alternate verified support.
6. Physical clock/spacing changes semantic meaning despite identical logical events.
7. Sensor concepts cannot remain stable before/after human naming.
8. Query cost approaches a whole-graph scan for ordinary bounded queries.
9. Proof/provenance overhead removes the claimed sparse-execution advantage.
10. A conventional indexed graph engine matches every semantic/reasoning benefit with less complexity.
11. Useful transfer only appears when a large dense model performs the real reasoning and NSPF is a passive store.
12. Candidate/utility scores repeatedly need to override proof/status to achieve acceptable outputs.
13. Truth, skill, episode and failure classes cannot be kept separated without unacceptable overhead.
14. Continual updates require full-system retraining comparable to weight-centric models.
15. The hardware cannot meet timing/resource constraints at the minimum useful working-set size.

## 31.1 Partial falsification

A failure of the strong form does not make the engineering work worthless. Possible narrower outcomes:

- Full Evidence remains a useful auditable FPGA knowledge engine.
- NSPF becomes a semantic control plane around neural perception.
- Event/graph caching yields useful hardware acceleration without broader cognitive claims.
- Sensor/skill learning remains bounded to specific capability classes.

## 31.2 Required intellectual discipline

Do not convert a failed hypothesis into a new definition after seeing results. Freeze the preregistered claim, retain negative evidence, and version any revised hypothesis as a new research artifact.
