# 03 — CORE DOCTRINE

## 3.1 Meaning vs representation

**[ESTABLISHED within project]** Bits and IDs are representation, not meaning. Meaning is carried by stable identity plus typed relations, context, observed effects and provenance.

```text
ALIAS != IDENTITY
NUMERIC_ID != MEANING
BIT_WIDTH != SEMANTIC_CLASS
```

Therefore the rejected design is:

```text
noun = 6-bit namespace
verb = 8-bit namespace
adjective = 10-bit namespace
```

The accepted design is:

```text
ID        = stable addressable identity
KIND      = semantic kind
CLASS     = ontology/capability class
ROLE      = contextual binding
STATE     = lifecycle/epistemic state
```

## 3.2 Persistent information vs activation

Persistent records live in the Binary Semantic Plane. Cognition is a transient sparse activation state over those records.

```text
persistent knowledge != current thought
stored edge          != activated edge
verified fact        != selected candidate
```

## 3.3 Truth vs utility

Q*, SPEAR, cache hotness, success counters and failure penalties express utility/preference, not truth.

```text
utility_score cannot promote fact
access_frequency cannot verify fact
reward cannot override legality
candidate rank cannot override conflict
```

ASTRA remains the authority for legality, proof, status, completeness and knowledge promotion.

## 3.4 Human-language boundary

Human language is a codec/adapter:

```text
text -> alias/intent resolution -> QueryRecord/EventRecord
ResultRecord -> rendering -> text
```

`is/am/are`, Vietnamese morphology or another language must not become core ontology. Equivalent language expressions normalize to native semantic predicates.

## 3.5 Learned vs deterministic

Hard/frozen:

- exact codecs, arithmetic primitives, type checks;
- capability format;
- protocol invariants;
- ASTRA status/proof laws;
- safety/legality;
- identity/version/checkpoint contracts.

Learned/adaptive:

- candidate semantic associations;
- Q*/SPEAR policy state;
- skill composition;
- failure/recovery patterns;
- context-conditioned utility;
- candidate causal relations awaiting verification.

## 3.6 Hardware clock doctrine

**[FALSIFIED]** physical frequency is not semantic identity. Use explicit logical ticks/sequence IDs. Clock and transport latency may change without changing meaning.
