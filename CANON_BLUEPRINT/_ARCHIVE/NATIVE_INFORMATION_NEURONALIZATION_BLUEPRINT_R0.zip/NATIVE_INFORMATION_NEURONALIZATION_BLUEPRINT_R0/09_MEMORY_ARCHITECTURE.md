# 09 — MEMORY ARCHITECTURE

## 9.1 Principle

Physical memory tier is a **placement decision**, not a cognitive truth class.

```text
VERIFIED_FACT may be cached in BRAM
SKILL may be hot in BRAM or cold in DDR
FAILURE remains FAILURE regardless of location
```

## 9.2 Tier model

### T0 — Immutable Semantic Control Plane

Registers/LUT/combinational/sequential logic for:

- primitive operators and exact compare;
- protocol/schema legality;
- ASTRA status/proof control rules;
- safety vetoes;
- routing/arbitration;
- fixed codecs.

Do not bake ordinary domain facts into T0 merely because they are popular.

### T1 — Hot Cognitive Working Store

BRAM/LUTRAM for:

- active frontier and visited state;
- current bindings/goal/query;
- hot directory/postings/edges/values;
- hot skill descriptors;
- proof scratch;
- small Q*/SPEAR state;
- FIFOs and protocol buffers.

### T2 — Canonical Cognitive Memory Store

DDR3/HBM for:

- verified graph/facts/provenance;
- candidate knowledge;
- episodic/failure journals;
- full skill library;
- long-term policies/checkpoints;
- cold indexes and proof artifacts.

## 9.3 Register and LUTRAM

Use for tiny state, counters, shallow queues and exact maps where synthesis shows benefit. Avoid accidental large LUTRAM inference.

## 9.4 BRAM semantic cache

Recommended logical partitions inside the same physical BRAM:

```text
Active Frontier       pinned / short lifetime
Hot Semantic Cache    admission-controlled
Skill Cache           independent policy
Proof Cache           independent policy
```

Admission and eviction are separate. Avoid pure “cache every miss.”

## 9.5 DDR

DDR is authoritative bulk storage on Arty. Latency is variable; do not hard-code a universal “20–30 cycles” assumption. Measure row behavior, MIG arbitration, queueing and traversal indirection.

## 9.6 HBM

**[SPECULATIVE until profiling]** HBM becomes justified when multi-walker random access and bandwidth are measured bottlenecks. Peak HBM bandwidth is not a guaranteed semantic-query bandwidth.

## 9.7 Future external memory

Larger systems may add NVMe/network/object storage behind a page service. Such storage is never directly on the proof-critical hot path without integrity/version checks.

## 9.8 Runtime promotion

Promotion changes location only:

```text
DDR canonical object
 -> shadow BRAM bank
 -> integrity/generation verify
 -> atomic directory commit
 -> active cache entry
```

## 9.9 Offline specialization / “sleep cycle”

Rename this **Semantic Hardware Specialization**:

```text
runtime hot/stable pattern
 -> export
 -> causal/benefit analysis
 -> RTL specialization candidate
 -> synth/P&R/timing/regression
 -> new bitstream / optional future DFX
```

A hot fact does not automatically become instinct. Specialize operators, stable micro-programs, decision predicates or repeated motifs only when measured benefit exceeds resource/verification cost.
