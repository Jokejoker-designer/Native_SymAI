# 10 — ACTIVATION AND ROUTING

## 10.1 Active frontier

The active frontier is the sparse set of semantic work items currently under consideration. The full graph is never “active” simultaneously.

```text
FrontierEntry {
  semantic_id
  incoming_relation
  depth
  path_cost
  context_id
  proof_parent
  flags
}
```

## 10.2 Activation descriptor

Activation is transient:

```text
ActivationDescriptor {
  semantic_id
  activation_reason
  frame_id
  logical_tick
  ttl
  priority
}
```

Activation does not alter truth status.

## 10.3 Event router

Responsibilities:

- classify event/query/result/control packets;
- route to Working Mind, graph walker, skill engine, ASTRA or learning lane;
- preserve transaction identity;
- enforce backpressure.

## 10.4 Backpressure

Queues expose occupancy/watermarks. No silent drop. Required outputs include overload status if bounded resources cannot accept more work.

## 10.5 Expiry

Transient activation/frontier entries carry TTL/budget. Expiry yields explicit search/budget status, not semantic falsity.

```text
budget exhausted -> SEARCH_INCOMPLETE
not -> UNKNOWN
```

## 10.6 Routing scale

Arty R0 uses one bounded router/shared fabric. Multi-tile packet NoC is deferred until a single-walker/multi-walker memory profile establishes need.
