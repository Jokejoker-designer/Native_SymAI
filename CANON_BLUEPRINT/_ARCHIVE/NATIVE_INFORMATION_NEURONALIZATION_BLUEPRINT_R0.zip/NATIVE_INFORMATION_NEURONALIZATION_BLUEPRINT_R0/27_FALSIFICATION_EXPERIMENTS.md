# 27 — FALSIFICATION EXPERIMENTS

Every experiment is preregistered with hypothesis, DUT, input, control, intervention, expected result, failure criterion and allowed claim.

## 27.1 ROLE_ORDER

**Hypothesis:** `KIND + ROLE + logical ordering` preserves frame semantics independent of physical spacing.

- **DUT:** event ingress + frame assembler.
- **Input:** same IDs/roles/logical ticks under different physical gaps.
- **Control:** swap SUBJECT/OBJECT roles while keeping IDs.
- **Intervention:** inject stalls/jitter; role swap separately.
- **Expected:** timing perturbation preserves result; role swap changes/rejects interpretation.
- **Fail:** raw cycle spacing changes meaning or swapped roles produce same frame semantics.
- **Allowed claim:** role binding is causally used and clock-spacing independent in tested bounds.

## 27.2 MASKED_SLOT

**Hypothesis:** a typed missing slot can be resolved from semantic constraints without answer-table lookup.

- **DUT:** NCG + constraint resolver + ASTRA.
- **Input:** frame `AGENT ? FOOD` with holdout IDs.
- **Control:** candidate-order shuffle and ID permutation.
- **Intervention:** remove one required support relation.
- **Expected:** supported candidate answers; ablated support -> UNKNOWN/INCOMPLETE as appropriate.
- **Fail:** exact training ID required, host supplies winner, or answer survives support removal.
- **Allowed claim:** bounded structural slot resolution is evidenced.

## 27.3 4BIT_TO_8BIT

**Hypothesis:** a learned parameterized procedure transfers across widths.

- **DUT:** Skill Engine + Working Mind; direct `ADD/INCREMENT` shortcut disabled for this experiment.
- **Input:** 4-bit training trajectories, unseen 8/16-bit exam.
- **Control:** literal-script baseline and bit-ID permutation.
- **Intervention:** width change and ID remap.
- **Expected:** carry/toggle abstraction transfers better than literal baseline.
- **Fail:** per-bit script or no transfer.
- **Allowed claim:** bounded structural transfer for tested procedure.

## 27.4 SENSOR_GROUNDING

**Hypothesis:** stable internal concept/effect relation can exist before human alias.

- **DUT:** benign sensor/GPIO + NCG + episode memory.
- **Input:** repeated action/effect observations without alias.
- **Control:** attach/rename alias after learning.
- **Intervention:** alias replacement and equivalent unseen capability instance.
- **Expected:** learned relations remain stable and transfer by class/effect.
- **Fail:** behavior collapses when alias changes.
- **Allowed claim:** effect-grounded internal identity is evidenced in bounded task.

## 27.5 CAUSAL_ABLATION

**Hypothesis:** semantic answer depends on declared support.

- **DUT:** Full Evidence/NSPF retrieval + ASTRA.
- **Input:** Pack A contains support; Pack B removes only that support.
- **Control:** exact same query, generation correctly switched.
- **Intervention:** runtime A -> B reload.
- **Expected:** A answers; B becomes UNKNOWN or another correctly supported state.
- **Fail:** old answer survives with no alternate support.
- **Allowed claim:** runtime-loaded evidence causally determines tested answer.

## 27.6 CLOCK_RATE_INVARIANCE

**Hypothesis:** semantics depends on logical events, not physical frequency.

- **DUT:** same RTL at two legal clocks or clock-enable schedules.
- **Input:** identical logical event sequence.
- **Control:** identical active pack/generation.
- **Intervention:** change physical rate/spacing.
- **Expected:** semantic result/proof invariant modulo timing metadata.
- **Fail:** meaning/status changes solely due to physical rate.
- **Allowed claim:** clock-rate invariance within tested configurations.

## 27.7 EVENT_JITTER_ROBUSTNESS

**Hypothesis:** bounded physical arrival variation is transport noise, not semantic information.

- **DUT:** ingress FIFO + assembler.
- **Input:** same sequence/ticks.
- **Control:** clean spacing.
- **Intervention:** seeded stalls/gaps/bounded async shifts.
- **Expected:** same semantic result, no duplicate/drop/deadlock.
- **Fail:** output change, event loss/duplication, parse deadlock.
- **Allowed claim:** event protocol is robust to preregistered jitter envelope.

## 27.8 Additional required experiments before R2 scale

Also preregister:

```text
DIRECT_RETRIEVAL
REVERSE_RETRIEVAL
MULTIHOP
VALUE_BINDING
CONTEXT_BINDING
PROVENANCE
TEACHER_CORRECTION
CONFLICT
UNKNOWN
LANGUAGE_ADAPTER_REMOVAL
MEMORY_SCALE
ENERGY_LATENCY
```

Each must use the same evidence template and retain negative results.
