# PACKAGE LOCK

This package is a forward research blueprint.

It SHALL NOT:

- modify or reinterpret frozen V1 evidence;
- inherit any previous BOARD_PASS into a new bitstream/schema/pack;
- redefine FE256 gold or acceptance thresholds;
- merge FACT, EPISODE, SKILL, FAILURE or POLICY_WEIGHT into one record class;
- let host/language tooling become semantic winner/proof authority;
- encode physical clock frequency or uncontrolled jitter as semantic meaning;
- claim that research hypotheses are implemented silicon evidence.

Promotion of any design element into Developmental_R1 requires a separate implementation contract and causal verification run.
