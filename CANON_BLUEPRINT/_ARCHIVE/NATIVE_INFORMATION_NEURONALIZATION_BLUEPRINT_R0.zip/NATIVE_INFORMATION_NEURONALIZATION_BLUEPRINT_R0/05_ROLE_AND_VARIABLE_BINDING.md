# 05 — ROLE AND VARIABLE BINDING

## 5.1 Semantic kind vs contextual role

A concept has stable KIND; a frame assigns temporary ROLE.

```text
HUMAN: KIND=AGENT
Frame A: ROLE=SUBJECT
Frame B: ROLE=OBJECT
```

This prevents English grammar from becoming ontology.

## 5.2 Role enum candidate

```text
SUBJECT
PREDICATE
OBJECT
SOURCE
TARGET
CAUSE
EFFECT
INSTRUMENT
LOCATION_ROLE
TEMPORAL_ROLE
CONDITION
GOAL_ROLE
VALUE_ROLE
```

## 5.3 Binding table

Working-memory candidate:

```text
BindingEntry {
  frame_id        u16
  slot_id         u8
  role            u8
  variable_id     u16
  semantic_id     u32
  kind_constraint u8
  flags           u8
  context_id      u32
}
```

BRAM/LUTRAM stores only active bindings.

## 5.4 Variable identity

Variable IDs are local to a frame/transaction and cannot be confused with persistent SemanticUnit IDs.

```text
VAR_X != NODE_X
```

## 5.5 Frame representation

Example:

```text
Frame 17
  slot0 ROLE=SUBJECT   -> HUMAN_1
  slot1 ROLE=PREDICATE -> ?VAR_ACTION
  slot2 ROLE=OBJECT    -> APPLE_1
```

Constraint resolution can request candidate actions whose domain/range/context satisfy the frame.

## 5.6 Missing slot

`MISSING_SLOT` is an explicit condition:

```text
MISSING_SLOT(frame_id, slot_id, role, kind_constraint, context)
```

It may trigger retrieve, infer, observe, act, skill-execute, ask-teacher or return UNKNOWN. No subsystem is allowed to guess-and-promote without ASTRA verification.
