# 26 — VERIFICATION

## 26.1 Philosophy

Correct output is insufficient. Verify representation, selection, causal dependence, learning state, transfer, authority and hardware integrity separately.

## 26.2 Ladder

```text
L0 reference model
L1 RTL unit
L2 XSim subsystem
L3 integrated hierarchy
L4 OOC synthesis/timing
L5 post-implementation
L6 physical board
```

Do not use L6 to discover basic logic bugs that should fail at L0–L4.

## 26.3 Reference model

Reference implementation must:

- parse the exact frozen ABI;
- implement bounded traversal and statuses;
- produce machine-readable proof steps;
- keep deterministic seeds/order for EXAM;
- remain independent enough from RTL packing logic to detect encoding mistakes.

## 26.4 RTL assertions

Minimum examples:

```text
assert !(commit && !legal)
assert !(q_update && !action_participated)
assert !(spear_update && !candidate_selected)
assert !(fifo_wr && fifo_full)
assert !(fifo_rd && fifo_empty)
assert !(exam_mode && exploration_enable)
valid && !ready -> payload stable
accepted_request -> exactly_one_commit
```

Add NSPF-specific assertions:

```text
semantic_status change -> ASTRA_authorized
cache promotion -> exact generation match
hash lookup hit -> full key match
logical sequence gap -> explicit fault
proof step -> referenced edge valid in active generation
```

## 26.5 XSim

XSim must cover:

- role binding and reordered timings;
- direct/reverse/multi-hop;
- typed value/range;
- status distinctions;
- CRC/duplicate/stale packet handling;
- cache hit/miss parity;
- ablation;
- reset/restore for learned state.

## 26.6 OOC / implementation

Every block reports LUT/FF/BRAM/DSP, inferred RAM/multiplier shape, WNS/TNS, hold, CDC and high-fanout risks.

## 26.7 Board

Board evidence requires exact source/bit/pack/schema identities, UART raw capture, runtime load/readback, benchmark results and limitations. `PROGRAM_PASS` means configuration only.

## 26.8 Failure discipline

On failure:

```text
freeze failing run
 -> classify first causal divergence
 -> minimal patch
 -> targeted regression
 -> rerun lower gates
 -> fresh full campaign after functional change
```

Never overwrite negative evidence.
