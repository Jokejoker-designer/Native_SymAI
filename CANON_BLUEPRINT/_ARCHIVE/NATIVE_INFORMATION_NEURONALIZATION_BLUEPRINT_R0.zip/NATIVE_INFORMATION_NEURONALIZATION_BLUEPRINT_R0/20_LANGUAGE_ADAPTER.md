# 20 — LANGUAGE ADAPTER

## 20.1 Boundary

Human language is outside the proof-critical core:

```text
text -> alias/intent resolver -> QueryRecord
StructuredResult -> renderer -> text
```

The adapter may resolve IDs. It may not perform hidden graph reasoning or answer lookup.

## 20.2 Multilingual aliases

One native ID may have multiple aliases:

```text
alias("human", en)
alias("con người", vi)
```

Changing language must not alter canonical semantics.

## 20.3 6W1H mapping

Candidate 3-bit native `QUERY_OPERATOR`:

```text
000 WHAT
001 WHO
010 WHERE
011 WHEN
100 WHY
101 WHICH
110 HOW
111 RESERVED
```

These codes represent query functions, not English words.

## 20.4 Text -> QueryRecord

Allowed host work:

- tokenize/parse human text;
- resolve aliases;
- normalize units;
- infer query operator/direction;
- construct canonical constraints.

Forbidden host work:

- choose answer;
- traverse hidden knowledge base for winner;
- construct proof on behalf of FPGA;
- encode expected benchmark answer in IDs/flags.

## 20.5 ResultRecord -> text

Renderer maps native status faithfully. Examples:

```text
ANSWER -> render answer/proof summary
UNKNOWN -> "insufficient verified support"
CONFLICT -> render conflict state, not a guessed winner
SEARCH_INCOMPLETE -> "search budget incomplete"
DATA_INTEGRITY_FAIL -> system/integrity error
```

## 20.6 Adapter parity

Different surface forms that resolve to the same canonical QueryRecord must produce the same semantic result. Parser failure is adapter failure, not knowledge UNKNOWN.
