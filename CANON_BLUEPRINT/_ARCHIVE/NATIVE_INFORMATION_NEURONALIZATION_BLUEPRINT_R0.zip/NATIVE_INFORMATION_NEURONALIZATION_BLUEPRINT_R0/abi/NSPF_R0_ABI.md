# NSPF R0 ABI QUICK REFERENCE

## Event packet

192 bits / 24 bytes. See `08_NATIVE_SEMANTIC_PULSE_PROTOCOL.md`.

## QueryRecord

256 bits / 32 bytes. Big concepts: fixed header, txn ID, query meta, subject/relation/object/context/value refs, search budget, CRC16.

## StructuredResult

Candidate 320 bits / 40 bytes. Carries semantic status, reason code, answer kind/ref/value, proof/provenance/context/conflict refs and completeness.

## Endianness

R0 recommendation: little-endian integer fields in host/DDR serialization, with bit ranges defined by generated ABI authority. UART frames carry explicit ABI version and length.

## Version rule

No binary reinterpretation across incompatible ABI generations. Unsupported required fields/flags cause reject, not coercion.
