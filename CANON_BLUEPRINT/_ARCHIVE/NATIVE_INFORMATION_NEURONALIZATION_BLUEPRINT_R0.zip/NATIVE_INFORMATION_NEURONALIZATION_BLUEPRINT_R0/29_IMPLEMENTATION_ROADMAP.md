# 29 — IMPLEMENTATION ROADMAP

## 29.1 Rule

One milestone = one primary causal question. Each milestone freezes:

```text
CONTRACT.md
RESULT.json
EVIDENCE.md
SHA256SUMS.txt
```

Add artifacts only when needed to reproduce/debug.

## 29.2 Phase A — Arty MVP

### A0 — Freeze research lane

- no mutation of frozen V1/FE evidence;
- create isolated NSPF worktree/folder;
- pin research/ABI source hashes.

### A1 — ABI + reference model

- Node/Edge/Value/Context/Provenance;
- SemanticEventPacket;
- QueryRecord/StructuredResult;
- pack compiler/verifier separation.

### A2 — NSPF-X0

- event ingress;
- frame binding;
- masked-slot resolver;
- proof builder;
- timing perturbation;
- causal ablation.

### A3 — Runtime DDR integration

- production loader/MIG;
- directory/posting caches;
- readback;
- FE256 parity.

### A4 — UART E2E

- Host language adapter;
- FE-UART-E2E-32.

Maximum claim: bounded explicit semantic/event execution on Arty.

## 29.3 Phase B — R1 laboratory

Only after Arty MVP gates pass:

- sensor grounding;
- candidate relation lifecycle;
- teacher active learning;
- parameterized skill transfer;
- FEM integration;
- cache profiler/admission experiments;
- optional HDC proposal sidecar.

Maximum claim: bounded structural transfer/grounding if causal tests pass.

## 29.4 Phase C — R2 HBM scale

Entry conditions:

- profiling proves DDR/random-access bottleneck;
- proof overhead characterized;
- single walker correct and deterministic;
- cache semantics stable.

Implement:

- partitioned graph;
- multi-walker;
- HBM channel mapping;
- semantic-event merge;
- larger active-frontier profiling.

## 29.5 Phase D — Hardware specialization research

After stable workload evidence:

- offline profiler export;
- profitability model;
- candidate microprogram/operator specialization;
- full bitstream rebuild first;
- DFX only later if rollback/timing/lineage can be verified safely.
