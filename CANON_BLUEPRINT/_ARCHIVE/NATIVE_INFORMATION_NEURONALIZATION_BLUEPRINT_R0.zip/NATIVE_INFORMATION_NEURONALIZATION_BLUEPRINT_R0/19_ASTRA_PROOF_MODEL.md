# 19 — ASTRA PROOF MODEL

## 19.1 Authority

ASTRA owns:

```text
legality
proof validity
conflict
completeness
status
knowledge promotion
```

Scores, cache hotness, teacher statements and language rendering cannot override these fields.

## 19.2 Proof object

Recommended binary object:

```text
ProofHeader {
  proof_id
  txn_id
  status
  rule_id
  step_count
  flags
  root_ref
}

ProofStep {
  edge_id
  source_id
  relation_or_rule
  target_or_value
}
```

## 19.3 Provenance chain

Every proof-relevant semantic step references source/provenance. Inference must preserve ancestry rather than emit only a final answer.

## 19.4 Status

Minimum R0 statuses:

```text
ANSWER
UNKNOWN
CONFLICT
SEARCH_INCOMPLETE
UNSUPPORTED_QUERY
DATA_INTEGRITY_FAIL
```

Transport/parser faults belong to protocol status, not semantic UNKNOWN.

## 19.5 Conflict

Opposing verified support yields `CONFLICT` or a conflict object; Q*/SPEAR cannot break the tie by utility and call it truth.

## 19.6 Completeness

Completeness is explicit:

```text
COMPLETE
PARTIAL
NOT_APPLICABLE
```

A partial proof or exhausted search cannot silently be rendered as a certain answer.
