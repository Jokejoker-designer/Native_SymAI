# 11 — WORKING MEMORY

## 11.1 Purpose

Working Memory is the bounded hot state needed for one active reasoning/learning context. It must remain small enough for deterministic on-chip implementation.

## 11.2 Contents

Recommended R0 fields:

```text
session_id
txn_id
generation
active_goal
active_query
binding_table
legal_mask
frontier queue
visited filter
candidate set
proof scratch
active skill descriptor
16–32 step trajectory
recent failure prototypes
policy/skill versions
```

## 11.3 Role bindings

Active frame slots are BRAM/LUTRAM records. Persistent semantic nodes remain canonical elsewhere. Bindings are transaction-scoped and must be cleared/versioned on reset, abort or generation change.

## 11.4 Active goal

Goal is an explicit semantic object/reference, not a string. Goal context may influence legal planning and utility, but not rewrite static truth.

## 11.5 Active query

The canonical query is a typed `QueryRecord`; human text is never retained as authority. Debug tooling may retain the original text as provenance only.

## 11.6 Frontier

Use bounded queues with:

- depth/path budget;
- relation masks;
- context constraints;
- proof parent references;
- explicit overflow/incomplete status.

## 11.7 Trajectory

Developmental trajectory stores only executed/observed steps. Unexecuted candidate actions must never receive causal credit.
