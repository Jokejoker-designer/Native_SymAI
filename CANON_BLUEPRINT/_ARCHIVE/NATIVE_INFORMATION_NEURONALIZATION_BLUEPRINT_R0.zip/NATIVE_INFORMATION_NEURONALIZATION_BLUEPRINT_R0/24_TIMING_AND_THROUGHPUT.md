# 24 — TIMING AND THROUGHPUT

## 24.1 Logical vs physical clocks

Semantic time is represented by logical tick/sequence fields. Physical FPGA cycles measure implementation latency only.

Clock-rate invariance requirement:

```text
same semantic packet sequence
+ same logical ticks
+ different legal physical spacing/clock enable
=> same semantic result/proof
```

## 24.2 DDR latency

Do not freeze a universal latency estimate into the architecture. Measure:

- MIG initialization and clock-domain behavior;
- row hit/miss patterns;
- read/write turnaround;
- arbitration/queueing;
- burst size;
- posting indirection;
- cache hit/miss penalty.

Report latency as distributions, not one number.

## 24.3 Event throughput

Metrics:

```text
accepted events/s
stalled events/s
FIFO high-water mark
drop/duplicate count (must be zero in valid runs)
router cycles/event
```

## 24.4 Traversal throughput

Metrics per query:

```text
index reads
posting pages
edge/value reads
frontier expansions
visited checks
proof steps
DDR bytes
cycles
time_ns
```

Target the relation:

```text
query cost ~= index cost + visited frontier cost + proof cost
```

Do not claim O(1) or O(log N) general reasoning unless the benchmark actually demonstrates the asymptotic behavior.

## 24.5 Pipeline ownership

On Arty, time-multiplex arithmetic and walkers where possible to protect timing/resource margin. Parallelism is added only after profiling.

## 24.6 Timing acceptance

For board-candidate RTL:

```text
WNS >= 0
TNS = 0
hold clean
critical DRC = 0
unconstrained semantic paths = 0
```

Preferred pre-board margin may be stricter (e.g. positive WNS reserve), but it must be declared before the run.
