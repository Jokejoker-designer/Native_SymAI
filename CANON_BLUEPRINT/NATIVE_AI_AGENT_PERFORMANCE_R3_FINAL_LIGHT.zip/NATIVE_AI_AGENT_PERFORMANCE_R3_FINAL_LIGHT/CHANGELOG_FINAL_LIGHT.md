# FINAL LIGHT CHANGELOG — v3.2.0

- Removed `native-metrics` completely: no Agent scoring, defect-rate tracking, CSV/HTML dashboard or performance ranking.
- Independent review is mandatory only for CDC and ASTRA Gatekeeper/authority logic.
- Normal RTL such as UART, BRAM controller and basic Graph Walker FSM uses local test/XSim and may proceed as DEV_DONE without waiting for another Agent.
- XSim/Vivado are the primary objective judges; documentation explicitly rejects the stronger claim that they are infallible because testbench/constraint defects can create false confidence.
- Solo mode is the default operational assumption: one Agent may continue; other Agents are optional specialists/fallbacks.
- `native-flow assess` now emits `merge_policy` and `independent_review_required`.
