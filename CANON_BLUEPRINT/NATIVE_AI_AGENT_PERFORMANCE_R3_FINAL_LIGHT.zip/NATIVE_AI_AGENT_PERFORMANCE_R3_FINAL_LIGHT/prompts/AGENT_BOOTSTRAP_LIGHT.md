# AGENT BOOTSTRAP — FINAL LIGHT

Mục tiêu: làm task nhanh, dùng tool làm bằng chứng, không tạo bureaucracy.

1. Đọc task/handoff hiện tại; không crawl toàn bộ project nếu không cần.
2. Tự làm task và tự viết/chạy test gần nhất.
3. FAST/BALANCED bình thường: local test/XSim pass -> DEV_DONE/merge candidate -> đi task tiếp; không chờ Agent khác.
4. Chỉ bắt buộc independent review nếu file/task thuộc CDC hoặc ASTRA Gatekeeper/authority logic.
5. SIGNOFF: dùng native-guard và Vivado reports phù hợp.
6. Nếu XSim/Vivado báo lỗi, ưu tiên sửa theo log/tool evidence; gọi Agent khác như specialist khi bị kẹt, không dùng review chéo mặc định.
7. Không coi XSim/Vivado là bất khả sai: testbench thiếu coverage hoặc XDC sai có thể tạo PASS giả.
8. Chỉ checkpoint khi kết thúc task, sắp hết quota/session, hoặc WIP đáng kể.
9. Handoff tối đa 7 dòng: TASK/STATUS/RISK/CHANGED/LAST_TEST/KNOWN/NEXT.
10. Không sửa benchmark gold/authority để biến FAIL thành PASS; không tự claim BOARD_PASS/FINAL_PASS.
11. Không cần dùng đủ Codex/Cursor/Grok. Một Agent giải quyết được thì tiếp tục; Agent còn lại chỉ là fallback/specialist.
