from native_flow.policy import assess, DEFAULT_POLICY


def test_fast_docs():
    r = assess(['docs/note.md'], DEFAULT_POLICY)
    assert r['risk'] == 'FAST'
    assert r['merge_policy'] == 'MERGE_AFTER_LOCAL_PASS'
    assert not r['independent_review_required']


def test_balanced_rtl_no_review():
    r = assess(['rtl/walker.sv'], DEFAULT_POLICY)
    assert r['risk'] == 'BALANCED'
    assert r['merge_policy'] == 'MERGE_AFTER_LOCAL_PASS'
    assert not r['independent_review_required']


def test_signoff_xdc():
    r = assess(['constraints/top.xdc'], DEFAULT_POLICY)
    assert r['risk'] == 'SIGNOFF'
    assert r['merge_policy'] == 'SIGNOFF_REQUIRED'


def test_signoff_abi():
    r = assess(['spec/abi_layout.json'], DEFAULT_POLICY)
    assert r['risk'] == 'SIGNOFF'
    assert not r['independent_review_required']


def test_cdc_requires_independent_review():
    r = assess(['rtl/cdc/cmd_fifo_cdc.sv'], DEFAULT_POLICY)
    assert r['risk'] == 'SIGNOFF'
    assert r['independent_review_required']
    assert r['merge_policy'] == 'INDEPENDENT_REVIEW_REQUIRED'


def test_astra_gatekeeper_requires_independent_review():
    r = assess(['rtl/astra_gatekeeper.sv'], DEFAULT_POLICY)
    assert r['risk'] == 'SIGNOFF'
    assert r['independent_review_required']
    assert r['merge_policy'] == 'INDEPENDENT_REVIEW_REQUIRED'
