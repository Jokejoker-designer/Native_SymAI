# NATIVE_AI_AGENT_PERFORMANCE_R3_FINAL_LIGHT

**Final policy:** phát triển nhanh trước, chỉ siết ở boundary có thể làm sai silicon/evidence.

> **Nhẹ mặc định. Tool làm giám khảo chính. Review độc lập chỉ cho CDC và ASTRA Gatekeeper.**

## Những gì đã bỏ hẳn

- Không chấm điểm Codex/Cursor/Grok.
- Không Defect Rate, Task Outcome History, routing score, CSV/HTML dashboard.
- Không bắt Agent review chéo code thường.
- Không yêu cầu dùng đủ 3 Agent nếu 1 Agent đã xử lý được task.

`native-metrics` đã bị loại khỏi package.

## 3 mức duy nhất

- `FAST`: docs/script/refactor/test nhỏ. Test gần nhất pass -> merge/dev tiếp.
- `BALANCED`: RTL/interface bình thường. XSim/selective regression; OOC synth khi thay đổi RTL đáng kể. Pass -> `DEV_DONE`/merge candidate, không chờ Agent khác.
- `SIGNOFF`: XDC/clock/reset/CDC/ABI/gold/authority/top/DDR/board/bitstream. Bật `native-guard` và evidence phù hợp.

## Chỉ 2 nơi bắt buộc Independent Review

1. **CDC / reset-domain crossing / memory-clock boundary**.
2. **ASTRA Gatekeeper / authority logic** nơi quyết định `VERIFIED`, `CONFLICT`, promotion/veto/status.

UART, BRAM controller thông thường, graph walker FSM cơ bản và RTL thường **không cần review chéo bắt buộc** nếu local test/XSim pass. Khi chúng đi vào full integration/bitstream thì vẫn chịu gate theo risk hiện tại.

## XSim/Vivado là giám khảo chính — nhưng không phải thần thánh

Ưu tiên bằng chứng từ tool thay cho tranh luận LLM:

```text
RTL -> Testbench/XSim -> Synthesis -> Timing/DRC/CDC khi cần
```

- XSim chứng minh behavior **trong testbench đã viết**.
- Vivado chứng minh synthesis/timing/DRC **theo constraint đang có**.
- Vì testbench hoặc XDC sai có thể tạo PASS giả, CDC và ASTRA vẫn có independent review bắt buộc; bitstream candidate vẫn cần constraint/lineage signoff.

## Daily flow

```powershell
py -m pip install -e .

native-flow --root D:\FPGA\PROJECT assess --git-diff
native-flow --root D:\FPGA\PROJECT done M3-WALKER --git-diff --test "XSim PASS" --next "next task"
```

`assess` trả thêm:

```text
merge_policy = MERGE_AFTER_LOCAL_PASS
             | SIGNOFF_REQUIRED
             | INDEPENDENT_REVIEW_REQUIRED
```

## Solo mode thực dụng

Một Agent có thể tự đi tiếp phần lớn project. Không cần chờ Codex/Cursor/Grok còn lại.

Chỉ escalation khi:

- CDC khó;
- ASTRA authority logic;
- timing/congestion không đóng được;
- tool báo lỗi khó chẩn đoán;
- chuẩn bị signoff/bitstream.

`native-orch` chỉ dùng khi cần takeover/quota failover. `native-guard` chỉ dùng khi risk tăng.

## 5 guard không được bỏ

1. Không sửa authority/gold âm thầm.
2. Functional change quan trọng không dùng evidence cũ để promote.
3. Source đổi trong active build => build invalid.
4. Bitstream promotion cần timing/CDC/constraint/lineage signoff.
5. `BOARD_PASS`/`FINAL_PASS` cần acceptance + owner review.

Đọc thêm `docs/LIGHTWEIGHT_GOVERNANCE.md`. Session thường chỉ cần README + prompt light + task hiện tại.
