# Final-light daily workflow
$ROOT = "D:\FPGA\YOUR_PROJECT"

# 1) Xem risk + merge policy
native-flow --root $ROOT assess --git-diff

# 2) RTL thường: tự viết TB, chạy XSim. PASS thì DEV_DONE/merge candidate, không chờ review.
native-flow --root $ROOT done M3-WALKER --git-diff `
  --test "XSim PASS" `
  --next "Integrate posting cache"

# 3) CDC hoặc ASTRA Gatekeeper: assess sẽ trả INDEPENDENT_REVIEW_REQUIRED.
#    Chỉ lúc đó mới gọi Agent khác review.

# 4) Khi sắp hết quota/session:
native-flow --root $ROOT checkpoint M3-WALKER --git-diff `
  --test "vectors 1-18 PASS" `
  --known "vector 19 chưa chạy" `
  --next "Run vectors 19-32"
