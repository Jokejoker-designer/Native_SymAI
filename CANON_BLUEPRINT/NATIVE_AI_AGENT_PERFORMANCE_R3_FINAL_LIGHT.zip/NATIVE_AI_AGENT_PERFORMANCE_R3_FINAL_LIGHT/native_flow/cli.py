from __future__ import annotations
import argparse, json, pathlib, time
from .policy import load_policy, assess, git_changed

def jp(x): print(json.dumps(x,indent=2,ensure_ascii=False,sort_keys=True))

def state_root(root:pathlib.Path):
    p=root/'.native_flow'; p.mkdir(parents=True,exist_ok=True); return p

def load_state(root:pathlib.Path):
    p=state_root(root)/'state.json'
    if p.exists():
        try:return json.loads(p.read_text(encoding='utf-8'))
        except Exception:pass
    return {'tasks':{}}

def save_state(root:pathlib.Path,s):
    p=state_root(root)/'state.json'; p.write_text(json.dumps(s,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')

def compact_md(task,status,files,last_test,known,next_step,risk):
    return f'''# {task}\nSTATUS: {status}\nRISK: {risk}\nCHANGED: {", ".join(files) if files else "(none)"}\nLAST_TEST: {last_test or "(not recorded)"}\nKNOWN: {known or "(none)"}\nNEXT: {next_step or "(none)"}\n'''

def main(argv=None):
    ap=argparse.ArgumentParser(prog='native-flow',description='Light-by-default, risk-escalated workflow for Native AI agents')
    ap.add_argument('--root',default='.')
    ap.add_argument('--policy')
    s=ap.add_subparsers(dest='cmd',required=True)
    s.add_parser('init')
    p=s.add_parser('assess'); p.add_argument('--file',action='append',default=[]); p.add_argument('--git-diff',action='store_true'); p.add_argument('--staged',action='store_true'); p.add_argument('--base'); p.add_argument('--stage'); p.add_argument('--risk',choices=['FAST','BALANCED','SIGNOFF'])
    p=s.add_parser('done'); p.add_argument('task'); p.add_argument('--status',default='DEV_DONE',choices=['DEV_DONE','BLOCKED','VERIFIED']); p.add_argument('--file',action='append',default=[]); p.add_argument('--git-diff',action='store_true'); p.add_argument('--test',default=''); p.add_argument('--known',default=''); p.add_argument('--next',dest='next_step',default=''); p.add_argument('--stage'); p.add_argument('--risk',choices=['FAST','BALANCED','SIGNOFF']); p.add_argument('--out')
    p=s.add_parser('checkpoint'); p.add_argument('task'); p.add_argument('--file',action='append',default=[]); p.add_argument('--git-diff',action='store_true'); p.add_argument('--test',default=''); p.add_argument('--known',default=''); p.add_argument('--next',dest='next_step',required=True); p.add_argument('--stage'); p.add_argument('--risk',choices=['FAST','BALANCED','SIGNOFF']); p.add_argument('--out')
    p=s.add_parser('show'); p.add_argument('task',nargs='?')
    a=ap.parse_args(argv); root=pathlib.Path(a.root).resolve(); pol=load_policy(pathlib.Path(a.policy) if a.policy else (root/'config/light_policy.json'))
    if a.cmd=='init':
        sr=state_root(root); jp({'ok':True,'state':str(sr/'state.json'),'policy':'light-by-default'}); return 0
    if a.cmd=='assess':
        files=list(a.file)
        if a.git_diff: files += git_changed(root,a.staged,a.base)
        jp(assess(files,pol,a.stage,a.risk)); return 0
    if a.cmd in ('done','checkpoint'):
        files=list(a.file)
        if a.git_diff: files += git_changed(root)
        r=assess(files,pol,a.stage,a.risk)
        status='WORKING' if a.cmd=='checkpoint' else a.status
        record={'task':a.task,'status':status,'risk':r['risk'],'merge_policy':r['merge_policy'],'independent_review_required':r['independent_review_required'],'files':r['files'],'last_test':a.test,'known':a.known,'next':a.next_step,'gates':r['gates'],'updated':time.time()}
        st=load_state(root); st['tasks'][a.task]=record; save_state(root,st)
        out=pathlib.Path(a.out) if a.out else state_root(root)/'handoffs'/f'{a.task}.md'; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(compact_md(a.task,status,r['files'],a.test,a.known,a.next_step,r['risk']),encoding='utf-8')
        jp({'ok':True,'handoff':str(out),'record':record}); return 0
    if a.cmd=='show':
        st=load_state(root); jp(st['tasks'].get(a.task) if a.task else st); return 0
    return 1

if __name__=='__main__': raise SystemExit(main())
