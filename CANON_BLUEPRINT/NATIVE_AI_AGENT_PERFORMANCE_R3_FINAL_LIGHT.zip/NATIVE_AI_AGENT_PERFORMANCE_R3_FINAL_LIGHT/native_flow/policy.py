from __future__ import annotations
import json, pathlib, subprocess

DEFAULT_POLICY = {
    "profiles": {
        "FAST": {
            "rank": 1,
            "gates": ["nearest_compile_or_unit_test"],
            "description": "Daily low-risk development. No cross-agent review. Merge after the nearest local test passes."
        },
        "BALANCED": {
            "rank": 2,
            "gates": ["nearest_regression", "xsim_if_rtl", "ooc_synth_if_material_rtl"],
            "description": "Normal RTL/interface development. XSim/selective regression first; OOC synthesis only when the RTL change is material."
        },
        "SIGNOFF": {
            "rank": 3,
            "gates": ["full_regression_as_applicable", "synth_impl", "setup_hold_timing", "cdc", "drc", "clock_interaction", "constraints_review", "artifact_lineage"],
            "description": "Critical boundary or bitstream/release work. Use objective FPGA tool evidence and lineage checks."
        }
    },
    "independent_review_patterns": [
        "**/cdc/**", "**/*cdc*.sv", "**/*cdc*.v", "**/*cdc*.svh", "**/*cdc*.vh",
        "**/*reset_sync*", "**/*reset_cdc*", "**/*async_reset*",
        "**/*astra*gatekeeper*.sv", "**/*astra*gatekeeper*.v", "**/*astra*gate*.sv", "**/*astra*gate*.v",
        "**/*astra*authority*"
    ],
    "signoff_patterns": [
        "*.xdc", "**/*.xdc", "**/clock*", "**/reset*", "**/cdc*",
        "**/cdc/**", "**/*cdc*.sv", "**/*cdc*.v", "**/*cdc*.svh", "**/*cdc*.vh",
        "**/*reset_sync*", "**/*reset_cdc*", "**/*async_reset*",
        "**/abi*", "**/*protocol*", "**/*gold*", "**/*benchmark*contract*",
        "**/PROJECT_GOAL_LOCK.md", "**/PACKAGE_LOCK.md", "**/AUTHORITY_PRECEDENCE.md",
        "**/*acceptance*", "**/*astra*authority*", "**/*astra*gatekeeper*", "**/top*.sv", "**/top*.v",
        "**/*mig*", "**/*ddr*controller*", "**/*board*", "**/*jtag*", "**/*uart*e2e*"
    ],
    "balanced_extensions": [".sv", ".v", ".vh", ".svh", ".tcl"],
    "balanced_patterns": ["rtl/**", "tb/**", "sim/**", "scripts/**", "native_guard/**", "native_orch/**"],
    "fast_extensions": [".md", ".txt", ".rst", ".json", ".yaml", ".yml", ".py", ".ps1"],
    "escalate_file_count_balanced": 8,
    "escalate_file_count_signoff": 30,
    "protected_patterns": [
        "**/PROJECT_GOAL_LOCK.md", "**/PACKAGE_LOCK.md", "**/AUTHORITY_PRECEDENCE.md",
        "**/*gold*", "**/*benchmark*contract*", "**/*.xdc"
    ]
}

def load_policy(path: pathlib.Path | None = None):
    if path and path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return DEFAULT_POLICY

def _match(path: str, pat: str) -> bool:
    p = path.replace("\\", "/")
    pp = pathlib.PurePosixPath(p)
    return pp.match(pat) or pp.name == pat or pp.match("**/" + pat)

def assess(files: list[str], policy: dict, stage: str | None = None, requested: str | None = None):
    norm = sorted({f.replace("\\", "/") for f in files if f.strip()})
    reasons = []
    risk = "FAST"
    if requested:
        risk = requested.upper()
        reasons.append(f"manual_override={risk}")
    else:
        if stage and stage.lower() in {"bitstream", "release", "board", "post_route", "signoff", "impl"}:
            risk = "SIGNOFF"
            reasons.append(f"critical_stage={stage}")
        if any(any(_match(f, p) for p in policy.get("signoff_patterns", [])) for f in norm):
            risk = "SIGNOFF"
            reasons.append("critical_file_pattern")
        elif len(norm) >= int(policy.get("escalate_file_count_signoff", 30)):
            risk = "SIGNOFF"
            reasons.append("large_change_set")
        elif any(pathlib.PurePosixPath(f).suffix.lower() in set(policy.get("balanced_extensions", [])) for f in norm):
            risk = "BALANCED"
            reasons.append("rtl_or_build_extension")
        elif any(any(_match(f, p) for p in policy.get("balanced_patterns", [])) for f in norm):
            risk = "BALANCED"
            reasons.append("shared_development_path")
        elif len(norm) >= int(policy.get("escalate_file_count_balanced", 8)):
            risk = "BALANCED"
            reasons.append("moderate_change_set")

    protected = [f for f in norm if any(_match(f, p) for p in policy.get("protected_patterns", []))]
    if protected and risk != "SIGNOFF":
        risk = "SIGNOFF"
        reasons.append("protected_path")

    review_files = [f for f in norm if any(_match(f, p) for p in policy.get("independent_review_patterns", []))]
    independent_review_required = bool(review_files)
    profile = policy["profiles"][risk]

    if independent_review_required:
        merge_policy = "INDEPENDENT_REVIEW_REQUIRED"
    elif risk == "SIGNOFF":
        merge_policy = "SIGNOFF_REQUIRED"
    else:
        merge_policy = "MERGE_AFTER_LOCAL_PASS"

    return {
        "risk": risk,
        "files": norm,
        "protected_files": protected,
        "independent_review_required": independent_review_required,
        "independent_review_files": review_files,
        "merge_policy": merge_policy,
        "gates": profile["gates"],
        "description": profile["description"],
        "reasons": reasons or ["default_light_policy"]
    }

def git_changed(root: pathlib.Path, staged=False, base=None):
    args = ["git", "diff", "--name-only"]
    if staged:
        args.insert(2, "--cached")
    if base:
        args.append(base)
    try:
        p = subprocess.run(args, cwd=root, capture_output=True, text=True, timeout=20)
        if p.returncode != 0:
            return []
        return [x.strip() for x in p.stdout.splitlines() if x.strip()]
    except Exception:
        return []
