# LIGHTWEIGHT GOVERNANCE — FINAL MINIMAL POLICY

## 1. Triết lý

Development-first, evidence-at-boundaries. Không biến workflow thành hệ KPI hay hệ review chéo liên tục.

Một Agent được quyền tự hoàn thành task, tự viết testbench, chạy XSim/synthesis và đi tiếp. Agent khác chỉ được gọi vào khi có giá trị kỹ thuật rõ ràng.

## 2. Review độc lập chỉ bắt buộc ở hai vùng

### CDC
Bao gồm crossing giữa clock domains, reset release giữa domains và ranh giới system-clock / memory-clock. Đây là nơi sim đồng bộ có thể bỏ sót lỗi metastability/protocol.

### ASTRA Gatekeeper
Bao gồm logic quyết định VERIFIED/CONFLICT, legality/veto, proof/status authority và promotion. Một lỗi ở đây có thể làm sai epistemic contract dù datapath vẫn chạy đúng.

Ngoài hai vùng trên, review chéo là optional/escalation, không phải gate mặc định.

## 3. Tool-first judge

Ưu tiên tool output thay cho tranh luận giữa LLM:

- syntax/elaboration: simulator/compiler;
- behavior: XSim + assertions/testbench;
- hardware realizability: Vivado synthesis;
- setup/hold: implementation timing;
- DRC/CDC/clock interaction: Vivado reports.

Không dùng câu "tool không bao giờ nói dối". Tool chỉ đúng trong phạm vi input, constraints và test coverage. Testbench thiếu case hoặc XDC sai vẫn có thể cho PASS giả.

## 4. Mức rủi ro

### FAST
Test gần nhất pass -> merge/dev tiếp.

### BALANCED
RTL bình thường: XSim/selective regression. OOC synthesis nếu logic/material resource thay đổi đáng kể. Không review chéo bắt buộc.

### SIGNOFF
XDC/clock/reset/CDC/ABI/gold/authority/top/DDR/board/bitstream: full gate tương ứng.

## 5. Trạng thái tối giản

- READY
- DOING
- DEV_DONE
- BLOCKED
- VERIFIED

`DEV_DONE` là đủ để development downstream tiếp tục. `VERIFIED` dành cho boundary/signoff.

## 6. Merge policy

- `MERGE_AFTER_LOCAL_PASS`: FAST/BALANCED bình thường.
- `INDEPENDENT_REVIEW_REQUIRED`: CDC hoặc ASTRA Gatekeeper.
- `SIGNOFF_REQUIRED`: critical boundary nhưng không thuộc hai module bắt buộc review chéo.

## 7. Solo mode

Nếu chỉ còn 1 Agent do quota, Agent đó vẫn tiếp tục:

```text
edit -> test -> XSim -> synth/OOC khi cần -> DEV_DONE -> next task
```

Không chờ Agent khác trừ hai independent-review boundaries hoặc final acceptance.

Khi stuck timing/CDC/authority thì dùng Agent khác như specialist/doctor, không dùng chúng như mandatory reviewer mọi task.

## 8. Timing

Timing vẫn là P0 nhưng không chạy full implementation sau mỗi edit:

- local RTL: XSim + OOC synth/timing estimate khi đáng kể;
- integration: implementation timing;
- bitstream: setup/hold + CDC + clock interaction + constraint coverage + lineage.

## 9. Checkpoint tối thiểu

Chỉ checkpoint khi dừng session/quota, kết thúc task hoặc có WIP quan trọng:

```text
TASK
STATUS
RISK
CHANGED
LAST_TEST
KNOWN
NEXT
```

Không tạo report dài cho task bình thường.
